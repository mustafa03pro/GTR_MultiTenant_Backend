package com.example.multi_tanent.tenant.leave.enums;

public enum WorkingDayRequirementMode {
    NONE,
    AT_LEAST_N_WORKING_DAYS
}