package com.example.multi_tanent.tenant.attendance.enums;

public enum IdentifierType {
    FINGERPRINT,
    FACE,
    RFID_CARD,
    PIN,
    OTHER
}
