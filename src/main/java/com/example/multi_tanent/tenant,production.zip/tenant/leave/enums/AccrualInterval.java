package com.example.multi_tanent.tenant.leave.enums;

public enum AccrualInterval {
    MONTHLY, QUARTERLY, HALF_YEARLY, YEARLY
}