package com.example.multi_tanent.tenant.base.dto;

import lombok.Data;

@Data
public class LeaveGroupRequest {
    private String code;
    private String name;
}