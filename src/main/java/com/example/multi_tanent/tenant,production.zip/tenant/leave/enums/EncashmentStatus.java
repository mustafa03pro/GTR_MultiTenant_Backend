package com.example.multi_tanent.tenant.leave.enums;

public enum EncashmentStatus {
    DRAFT, SUBMITTED, APPROVED, REJECTED, PAID
}
