package com.example.multi_tanent.tenant.leave.entity;

public class WeekBreakPolicy {
    
}
