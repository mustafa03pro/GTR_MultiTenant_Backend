package com.example.multi_tanent.tenant.base.entity;

public class AttendanceCaptureScheme {
    
}
