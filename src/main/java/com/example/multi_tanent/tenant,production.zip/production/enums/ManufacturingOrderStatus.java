package com.example.multi_tanent.production.enums;

public enum ManufacturingOrderStatus {
    SCHEDULED,
    IN_PROGRESS,
    PAUSED,
    COMPLETED,
    CANCELLED
}
