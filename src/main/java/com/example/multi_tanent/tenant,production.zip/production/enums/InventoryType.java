package com.example.multi_tanent.production.enums;

public enum InventoryType {
    RAW_MATERIAL,
    FINISHED_GOOD,
    SERVICE,
    OTHER, SEMI_FINISHED_GOOD
}
