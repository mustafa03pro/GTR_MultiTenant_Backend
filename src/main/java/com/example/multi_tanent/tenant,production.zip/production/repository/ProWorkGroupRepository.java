package com.example.multi_tanent.production.repository;

import com.example.multi_tanent.production.entity.ProWorkGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProWorkGroupRepository extends JpaRepository<ProWorkGroup, Long> {
    
}
