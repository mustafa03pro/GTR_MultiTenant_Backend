package com.example.multi_tanent.production.repository;

import com.example.multi_tanent.production.entity.ProWorkStation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProWorkStationRepository extends JpaRepository<ProWorkStation, Long> {
}