package com.example.multi_tanent.production.repository;

import com.example.multi_tanent.production.entity.ProProcessWorkGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProProcessWorkGroupRepository extends JpaRepository<ProProcessWorkGroup, Long> {
}