package com.example.multi_tanent.production.enums;

public enum ItemType {
    PRODUCT,
    SERVICE
}