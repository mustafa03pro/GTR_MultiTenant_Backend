package com.example.multi_tanent.spersusers.enums;

public enum Gender {
    MALE,
    FEMALE,
    NOT_SPECIFIED
}
