package com.example.multi_tanent.tenant.leave.enums;

public enum AccrualType {
    ENTIRE_QUOTA,   // “Entire annual quota … can be availed anytime”
    PERIODIC        // “Leaves are accrued at regular intervals”
}