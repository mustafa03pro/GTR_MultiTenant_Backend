package com.example.multi_tanent.tenant.leave.enums;

public enum LeaveStatus {
    SUBMITTED, APPROVED, REJECTED, CANCELLED
}
