package com.example.multi_tanent.tenant.payroll.enums;

public enum ProvisionStatus {
    ACCRUING,
    PAID_OUT,
    EXPIRED,
    CANCELLED
}