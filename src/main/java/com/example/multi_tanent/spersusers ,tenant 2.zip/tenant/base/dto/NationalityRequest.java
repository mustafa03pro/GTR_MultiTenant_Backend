package com.example.multi_tanent.tenant.base.dto;

import lombok.Data;

@Data
public class NationalityRequest {
    private String name;
    private String isoCode;
}