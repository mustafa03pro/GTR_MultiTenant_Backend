package com.example.multi_tanent.tenant.leave.enums;

public enum EligibilityAnchor {
    AFTER_PROBATION,
    AFTER_JOINING
}