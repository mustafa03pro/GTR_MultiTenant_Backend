package com.example.multi_tanent.tenant.leave.enums;

public enum NegativeBalancePolicy {
    DEDUCT_FROM_SALARY,
    NULLIFY,
    CARRY_FORWARD_NEGATIVE
}