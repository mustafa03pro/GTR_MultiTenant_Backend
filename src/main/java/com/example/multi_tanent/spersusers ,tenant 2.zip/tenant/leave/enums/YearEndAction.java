package com.example.multi_tanent.tenant.leave.enums;

public enum YearEndAction {
    EXPIRE_OR_RESET,
    PAY_OUT,
    CARRY_FORWARD,
    PAY_THEN_CARRY,
    CARRY_THEN_PAY
}