package com.example.multi_tanent.tenant.leave.enums;

public enum MidYearJoinProratePolicy {
    PRORATE_ON_JOIN_DATE,
    FULL_QUOTA
}