package com.example.multi_tanent.tenant.payroll.enums;

public enum SalaryComponentType {
    EARNING,
    DEDUCTION,
    STATUTORY_CONTRIBUTION,
    REIMBURSEMENT
}