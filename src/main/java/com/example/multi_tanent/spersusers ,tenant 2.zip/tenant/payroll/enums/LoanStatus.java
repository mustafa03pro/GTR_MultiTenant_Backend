package com.example.multi_tanent.tenant.payroll.enums;

public enum LoanStatus {
    SUBMITTED,
    APPROVED,
    REJECTED,
    ACTIVE,
    PAID_OFF
}