package com.example.multi_tanent.tenant.leave.enums;

public enum AnnualQuotaLimitType {
    LIMITED,   // limit to fixed number of days/year
    UNLIMITED
}