package com.example.multi_tanent.tenant.leave.enums;

public enum ApproverSelectionMode {
    ROLE_BASED, NAMED_EMPLOYEES
}