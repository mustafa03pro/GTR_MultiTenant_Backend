package com.example.multi_tanent.tenant.payroll.enums;

public enum PayrollStatus {
    DRAFT,
    GENERATED,
    PAID,
    REVERTED, PROCESSING, COMPLETED
}