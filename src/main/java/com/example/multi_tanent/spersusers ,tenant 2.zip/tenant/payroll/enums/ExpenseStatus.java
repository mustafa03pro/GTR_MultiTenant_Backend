package com.example.multi_tanent.tenant.payroll.enums;

public enum ExpenseStatus {
    SUBMITTED,
    APPROVED,
    REJECTED,
    REIMBURSED
}