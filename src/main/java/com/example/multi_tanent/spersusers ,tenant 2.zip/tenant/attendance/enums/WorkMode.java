package com.example.multi_tanent.tenant.attendance.enums;

public enum WorkMode {
    ONSITE,
    HYBRID,
    REMOTE
}
