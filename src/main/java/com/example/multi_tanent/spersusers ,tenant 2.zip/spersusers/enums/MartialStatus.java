package com.example.multi_tanent.spersusers.enums;

public enum MartialStatus {
    SINGLE,
    MARRIED,
    DIVORCED
}