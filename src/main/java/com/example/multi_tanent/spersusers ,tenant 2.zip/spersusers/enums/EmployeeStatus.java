package com.example.multi_tanent.spersusers.enums;

public enum EmployeeStatus {
    ONBOARDING,
    ACTIVE,
    INACTIVE,
    TERMINATED
}
