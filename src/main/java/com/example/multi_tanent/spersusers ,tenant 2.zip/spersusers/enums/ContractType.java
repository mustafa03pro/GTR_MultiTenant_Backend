package com.example.multi_tanent.spersusers.enums;

public enum ContractType {
    LIMITED,
    UNLIMITED
}