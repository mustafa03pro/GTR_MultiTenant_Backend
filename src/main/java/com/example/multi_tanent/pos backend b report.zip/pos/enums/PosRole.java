package com.example.multi_tanent.pos.enums;

public enum PosRole {
    POS_MANAGER,POS_ADMIN,POS_CASHIER
}
