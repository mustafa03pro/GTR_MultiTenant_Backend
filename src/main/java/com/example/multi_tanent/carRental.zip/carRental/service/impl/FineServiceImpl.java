package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.model.Fine;
import com.example.multi_tanent.warehouse.repository.FineRepository;
import com.example.multi_tanent.warehouse.service.FineService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FineServiceImpl implements FineService {
    private final FineRepository repo;
    public FineServiceImpl(FineRepository repo) { this.repo = repo; }

    @Override
    public List<Fine> findAll() { return repo.findAll(); }

    @Override
    public Fine create(Fine fine) { fine.setIssuedAt(LocalDateTime.now()); return repo.save(fine); }

    @Override
    public Fine findById(Long id) { return repo.findById(id).orElseThrow(() -> new RuntimeException("Fine not found")); }
}
