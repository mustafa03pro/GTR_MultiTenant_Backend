package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.Pricing;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PricingRepository extends JpaRepository<Pricing, Long> {
    Optional<Pricing> findByCategory(String category);
}
