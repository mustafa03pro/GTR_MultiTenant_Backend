package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.exception.ResourceNotFoundException;
import com.example.multi_tanent.warehouse.model.Pricing;
import com.example.multi_tanent.warehouse.model.Vehicle;
import com.example.multi_tanent.warehouse.repository.PricingRepository;
import com.example.multi_tanent.warehouse.repository.VehicleRepository;
import com.example.multi_tanent.warehouse.service.PricingService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PricingServiceImpl implements PricingService {
    private final PricingRepository repo;
    private final VehicleRepository vehicleRepository ;

    public PricingServiceImpl(PricingRepository repo, VehicleRepository vehicleRepository) {
        this.repo = repo;
        this.vehicleRepository = vehicleRepository;
    }

    @Override
    public List<Pricing> findAll() { return repo.findAll(); }

    @Override
    public Pricing create(Pricing pricing) { return repo.save(pricing); }

    @Override
    public Pricing findById(Long id) { return repo.findById(id).orElseThrow(() -> new RuntimeException("Pricing not found")); }

    @Override
    public Pricing findByCategory(String category) {
        return repo.findByCategory(category)
                .orElseThrow(() -> new ResourceNotFoundException("Pricing not found for category: " + category));
    }

    @Override
    public Double getDiscountForCategory(String category) {
        Pricing pricing = findByCategory(category);
        return pricing.getDiscountPercentage();
    }

    @Override
    public Double getExcessMileageCharge(Long pricingId) {
        Pricing pricing = findById(pricingId);
        return pricing.getExcessMileagePerKm();
    }

    @Override
    public double calculateTotalPriceWithExtras(Long vehicleId, int rentalDays, double excessMiles, String category) {
        Pricing pricing = findByCategory(category);
        double basePrice = pricing.getDailyRate() * rentalDays;

        double discount = pricing.getDiscountPercentage() == null ? 0 : pricing.getDiscountPercentage();
        double discountPrice = basePrice - (basePrice * discount / 100);

        double excessCharge = 0;
        if (excessMiles > 0) {
            double perKmCharge = pricing.getExcessMileagePerKm();
            excessCharge = excessMiles * perKmCharge;
        }
        return discountPrice + excessCharge;
    }
}
