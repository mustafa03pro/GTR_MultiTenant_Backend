package com.example.multi_tanent.carRental.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.multi_tanent.carRental.dto.VehicleDto;
import com.example.multi_tanent.carRental.model.Vehicle;
import com.example.multi_tanent.carRental.service.FileStorageService;
import com.example.multi_tanent.carRental.service.VehicleService;

import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    private final VehicleService vehicleService;
    private final FileStorageService fileStorageService;

    @Autowired
    public VehicleController(VehicleService vehicleService, FileStorageService fileStorageService) {
        this.vehicleService = vehicleService;
        this.fileStorageService = fileStorageService;
    }

    // ✅ ADMIN — view all vehicles
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Vehicle>> listAll() {
        return ResponseEntity.ok(vehicleService.findAll());
    }

    // ✅ USER — view only available vehicles
    @GetMapping("/available")
    public ResponseEntity<List<Vehicle>> available() {
        return ResponseEntity.ok(vehicleService.findByStatus("AVAILABLE"));
    }

    // ✅ ADMIN — add new vehicle (Multipart version with optional image)
    @PostMapping("/save")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Vehicle> create(
            @RequestPart("vehicle") VehicleDto vehicleDto,
            @RequestPart(value = "image", required = false) MultipartFile imageFile) {

        Vehicle vehicle = new Vehicle();

        vehicle.setPlateNumber(vehicleDto.getPlateNumber());
        vehicle.setMake(vehicleDto.getMake());
        vehicle.setModel(vehicleDto.getModel());
        vehicle.setEngine(vehicleDto.getEngine());
        vehicle.setYear(vehicleDto.getYear());
        vehicle.setColor(vehicleDto.getColor());

        vehicle.setDailyRate(vehicleDto.getDailyRate());
        vehicle.setWeeklyRate(vehicleDto.getWeeklyRate());
        vehicle.setMonthlyRate(vehicleDto.getMonthlyRate());
        vehicle.setYearlyRate(vehicleDto.getYearlyRate());

        vehicle.setCurrentOdometer(0.0);
        vehicle.setKmsLimit(vehicleDto.getKmsLimit());
        vehicle.setExtraKmCharge(vehicleDto.getExtraKmCharge());
        vehicle.setDailyOdometerLimit(vehicleDto.getDailyOdometerLimit());
        vehicle.setOdometerExtraFeesPerUnit(vehicleDto.getOdometerExtraFeesPerUnit());

        vehicle.setLicenseIssuanceDate(vehicleDto.getLicenseIssuanceDate());
        vehicle.setLicenseExpiryDate(vehicleDto.getLicenseExpiryDate());
        vehicle.setCurrentLocation(vehicleDto.getCurrentLocation());
        vehicle.setStatus("AVAILABLE");
        vehicle.setSalikAccount(vehicleDto.getSalikAccount());
        vehicle.setPlateCategory(vehicleDto.getPlateCategory());
        vehicle.setVehicleCategories(vehicleDto.getVehicleCategories());

        // ✅ If image is provided, save and store URL
        if (imageFile != null && !imageFile.isEmpty()) {
            String fileName = fileStorageService.storeFile(imageFile);
            vehicle.setImageUrl("/uploads/" + fileName);
        } else if (vehicleDto.getImageUrl() != null) {
            vehicle.setImageUrl(vehicleDto.getImageUrl());
        }

        Vehicle savedVehicle = vehicleService.save(vehicle);
        return ResponseEntity.ok(savedVehicle);
    }

    // ✅ ADMIN — Add new vehicle using simple JSON (no multipart)
    // For testing easily in Postman without uploading image
    @PostMapping("/save-json")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Vehicle> createJson(@RequestBody VehicleDto vehicleDto) {

        Vehicle vehicle = new Vehicle();

        vehicle.setPlateNumber(vehicleDto.getPlateNumber());
        vehicle.setMake(vehicleDto.getMake());
        vehicle.setModel(vehicleDto.getModel());
        vehicle.setEngine(vehicleDto.getEngine());
        vehicle.setYear(vehicleDto.getYear());
        vehicle.setColor(vehicleDto.getColor());

        vehicle.setDailyRate(vehicleDto.getDailyRate());
        vehicle.setWeeklyRate(vehicleDto.getWeeklyRate());
        vehicle.setMonthlyRate(vehicleDto.getMonthlyRate());
        vehicle.setYearlyRate(vehicleDto.getYearlyRate());

        vehicle.setCurrentOdometer(vehicleDto.getCurrentOdometer());
        vehicle.setKmsLimit(vehicleDto.getKmsLimit());
        vehicle.setExtraKmCharge(vehicleDto.getExtraKmCharge());
        vehicle.setDailyOdometerLimit(vehicleDto.getDailyOdometerLimit());
        vehicle.setOdometerExtraFeesPerUnit(vehicleDto.getOdometerExtraFeesPerUnit());

        vehicle.setLicenseIssuanceDate(vehicleDto.getLicenseIssuanceDate());
        vehicle.setLicenseExpiryDate(vehicleDto.getLicenseExpiryDate());
        vehicle.setCurrentLocation(vehicleDto.getCurrentLocation());
        vehicle.setStatus("AVAILABLE");
        vehicle.setSalikAccount(vehicleDto.getSalikAccount());
        vehicle.setPlateCategory(vehicleDto.getPlateCategory());
        vehicle.setVehicleCategories(vehicleDto.getVehicleCategories());
        vehicle.setImageUrl(vehicleDto.getImageUrl());

        Vehicle savedVehicle = vehicleService.save(vehicle);
        return ResponseEntity.ok(savedVehicle);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<Vehicle> get(@PathVariable Long id) {
        return ResponseEntity.ok(vehicleService.findById(id));
    }

    // ✅ ADMIN — update vehicle details
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Vehicle> update(@PathVariable Long id, @RequestBody Vehicle vehicle) {
        return ResponseEntity.ok(vehicleService.updateVehicleDetails(id, vehicle));
    }

    // ✅ ADMIN — delete vehicle by ID
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        vehicleService.deleteById(id);
        return ResponseEntity.ok("Vehicle deleted successfully");
    }
}
