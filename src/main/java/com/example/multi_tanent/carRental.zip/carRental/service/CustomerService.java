package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Customer;
import java.util.List;

public interface CustomerService {
    Customer createCustomer(Customer customer);
    Customer updateCustomer(Long id, Customer customer);
    List<Customer> getAllCustomers();
    Customer getCustomerById(Long id);
    Customer getCustomerByEmail(String email);  // Changed to return Customer
    void deleteCustomer(Long id);
}
