package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentRepository extends JpaRepository<Payment , Long> {
}
