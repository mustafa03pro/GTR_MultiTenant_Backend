package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.Agreement;
import com.example.multi_tanent.warehouse.service.AgreementService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/agreements")
public class AgreementController {
    private final AgreementService service;
    public AgreementController(AgreementService service) { this.service = service; }

    @GetMapping
    public ResponseEntity<List<Agreement>> list() { return ResponseEntity.ok(service.findAll()); }

    @PostMapping
    public ResponseEntity<Agreement> create(@RequestBody Agreement agreement) { return ResponseEntity.ok(service.create(agreement)); }

    @GetMapping("/{id}")
    public ResponseEntity<Agreement> get(@PathVariable Long id) { return ResponseEntity.ok(service.findById(id)); }
}
