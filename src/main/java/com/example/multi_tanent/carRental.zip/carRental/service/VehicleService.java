package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Vehicle;
import java.util.List;

public interface VehicleService {
    List<Vehicle> findAll();
    Vehicle save(Vehicle vehicle);
    Vehicle findById(Long id);
    Vehicle updateVehicleDetails(Long id, Vehicle vehicle);
    List<Vehicle> findByStatus(String status);
    void deleteById(Long id);

    /**
     * Updates GPS location, calculates odometer movement, and saves location history.
     */
    Vehicle updateVehicleLocation(Long id, Double latitude, Double longitude, String address, Long timestamp);

    /**
     * Manually increments odometer (optional for future use)
     */
    void incrementOdometer(Long id, double kms);
}
