package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    Optional<Invoice> findByBooking_Id(Long bookingId);
}
