package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.model.Agreement;
import com.example.multi_tanent.warehouse.repository.AgreementRepository;
import com.example.multi_tanent.warehouse.service.AgreementService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AgreementServiceImpl implements AgreementService {
    private final AgreementRepository repo;

    public AgreementServiceImpl(AgreementRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<Agreement> findAll() {
        return repo.findAll();
    }

    @Override
    public Agreement create(Agreement agreement) {
        agreement.setStatus("DRAFT");
        return repo.save(agreement);
    }

    @Override
    public Agreement findById(Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Agreement not found"));
    }
}
