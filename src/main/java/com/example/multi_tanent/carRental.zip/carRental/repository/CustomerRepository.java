package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer , Long> {
    boolean existsByEmail(String email);

    // Add this method to find Customer by email, returns Optional
    Optional<Customer> findByEmail(String email);
}
