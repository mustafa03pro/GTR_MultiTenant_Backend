package com.example.multi_tanent.warehouse.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "vehicles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Basic details
    @Column(name = "vehicle_plate_number", nullable = false)
    private String plateNumber;

    @Column(name = "vehicle_make", nullable = false)
    private String make;

    @Column(name = "vehicle_model", nullable = false)
    private String model;

    @Column(name = "vehicle_engine", nullable = false)
    private String engine;

    @Column(name = "vehicle_year")
    private Integer year;

    @Column(name = "vehicle_color")
    private String color;

    // Rates
    @Column(name = "vehicle_daily_rate")
    private Double dailyRate;

    @Column(name = "vehicle_weekly_rate")
    private Double weeklyRate;

    @Column(name = "vehicle_monthly_rate")
    private Double monthlyRate;

    @Column(name = "vehicle_yearly_rate")
    private Double yearlyRate;

    // License & Insurance
    private LocalDate licenseIssuanceDate;
    private LocalDate licenseExpiryDate;
    private LocalDate insuranceExpiryDate;
    private String insuranceProviderName;

    // Location & Status
    private String currentLocation;
    private String status; // AVAILABLE, RENTED, MAINTENANCE, BOOKED
    private String lastKnownAddress;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    // Vehicle operational data
    private Double currentOdometer;

    private Double dailyOdometerLimit;
    private Double odometerExtraFeesPerUnit;
    private Double currentFuel;

    // Additional fields
    private String plateCategory;
    private String salikAccount;
    private String category; // primary category

    @ElementCollection
    @CollectionTable(name = "vehicle_categories", joinColumns = @JoinColumn(name = "vehicle_id"))
    @Column(name = "category_name")
    private List<String> vehicleCategories;

    private String imageUrl;

    private Double kmsLimit;
    private Double extraKmCharge;

    // 🟢 Transient fields (NOT stored in DB, used only in calculations)
    @Transient
    private Double extraKm;      // how many KM exceeded during booking

    @Transient
    private Double extraCharge;  // total extra charge due (calculated)
}
