package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.model.Booking;
import com.example.multi_tanent.warehouse.model.BookingStatus;
import com.example.multi_tanent.warehouse.model.Payment;
import com.example.multi_tanent.warehouse.repository.BookingRepository;
import com.example.multi_tanent.warehouse.repository.PaymentRepository;
import com.example.multi_tanent.warehouse.service.InvoiceService;
import com.example.multi_tanent.warehouse.service.PaymentService;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final InvoiceService invoiceService;

    @Value("${stripe.secret.key}")
    private String stripeSecretKey;

    public PaymentServiceImpl(BookingRepository bookingRepository,
                              PaymentRepository paymentRepository,
                              InvoiceService invoiceService) {
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
        this.invoiceService = invoiceService;
    }

    @Override
    public List<Payment> findAll() {
        return paymentRepository.findAll();
    }

    @Override
    public Payment findById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
    }

    @Override
    public Payment save(Payment payment) {
        return paymentRepository.save(payment);
    }

    /**
     * ✅ Create Stripe Payment Session (Includes Rent + Extra Amount)
     */
    @Override
    public Map<String, Object> createStripeSession(Map<String, Object> data) throws StripeException {
        Stripe.apiKey = stripeSecretKey;

        System.out.println("🧾 [DEBUG] Stripe session creation request data: " + data);

        if (data == null || !data.containsKey("bookingId")) {
            throw new IllegalArgumentException("Missing required field: bookingId");
        }

        Long bookingId = Long.parseLong(data.get("bookingId").toString());
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found with ID: " + bookingId));

        // ✅ Calculate total: rent + extra
        double rent = booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0;
        double extra = booking.getExtraAmount() != null ? booking.getExtraAmount() : 0.0;
        double total = rent + extra;

        if (total <= 0) {
            throw new IllegalArgumentException("Invalid payment amount for bookingId=" + bookingId);
        }

        long amountInPaise = (long) (total * 100);
        String currency = "INR";
        String name = booking.getVehicle() != null
                ? booking.getVehicle().getMake() + " " + booking.getVehicle().getModel()
                : "Car Rental Booking";

        System.out.println("💰 [INFO] Creating Stripe session for ₹" + total + " (bookingId=" + bookingId + ")");

        SessionCreateParams.LineItem.PriceData.ProductData productData =
                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                        .setName(name)
                        .build();

        SessionCreateParams.LineItem.PriceData priceData =
                SessionCreateParams.LineItem.PriceData.builder()
                        .setCurrency(currency)
                        .setUnitAmount(amountInPaise)
                        .setProductData(productData)
                        .build();

        SessionCreateParams.LineItem lineItem =
                SessionCreateParams.LineItem.builder()
                        .setQuantity(1L)
                        .setPriceData(priceData)
                        .build();

        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:3000/payment-success?bookingId=" + bookingId)
                .setCancelUrl("http://localhost:3000/payment-cancel")
                .addLineItem(lineItem)
                .build();

        Session session = Session.create(params);

        System.out.println("✅ [DEBUG] Stripe session created successfully: " + session.getUrl());

        Map<String, Object> response = new HashMap<>();
        response.put("sessionId", session.getId());
        response.put("sessionUrl", session.getUrl());
        response.put("amount", total);
        response.put("currency", currency);

        return response;
    }

    /**
     * ✅ Confirm Payment & Update Booking
     */
    @Override
    public Payment confirmStripePayment(Map<String, Object> data) {
        System.out.println("🧾 [DEBUG] Confirm payment data: " + data);

        if (data == null || !data.containsKey("bookingId")) {
            throw new IllegalArgumentException("Booking ID missing in confirm payment request");
        }

        Long bookingId = Long.parseLong(data.get("bookingId").toString());
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found with ID: " + bookingId));

        double rent = booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0;
        double extra = booking.getExtraAmount() != null ? booking.getExtraAmount() : 0.0;
        double totalPaid = rent + extra;

        Payment payment = new Payment();
        payment.setAmount(totalPaid);
        payment.setMethod("STRIPE");
        payment.setStatus("COMPLETED");
        payment.setPaidAt(LocalDateTime.now());
        payment.setBooking(booking);

        Payment savedPayment = paymentRepository.save(payment);

        // ✅ Update Booking
        booking.setStatus(BookingStatus.CONFIRMED);
        bookingRepository.save(booking);

        // ✅ Generate Invoice
        invoiceService.createInvoiceForBooking(booking, payment);

        System.out.println("✅ [INFO] Payment confirmed for Booking ID " + bookingId + ", Total Paid ₹" + totalPaid);
        return savedPayment;
    }
}
