package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Branch;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface BranchService {
    List<Branch> findAll();
    Branch save(Branch branch);
    Branch findById(Long id);
}
