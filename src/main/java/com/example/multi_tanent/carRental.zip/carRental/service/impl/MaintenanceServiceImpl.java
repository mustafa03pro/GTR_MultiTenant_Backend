package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.model.Maintenance;
import com.example.multi_tanent.warehouse.repository.MaintenanceRepository;
import com.example.multi_tanent.warehouse.service.EmailService;
import com.example.multi_tanent.warehouse.service.MaintenanceService;
import org.springframework.cglib.core.Local;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MaintenanceServiceImpl implements MaintenanceService {
    private final MaintenanceRepository repo ;
    private final EmailService emailService ;

    public MaintenanceServiceImpl(MaintenanceRepository repo, EmailService emailService) {
        this.repo = repo;
        this.emailService = emailService;
    }

    @Override
    public List<Maintenance> findAll() { return repo.findAll(); }

    @Override
    public Maintenance create(Maintenance maintenance) { maintenance.setStatus("PENDING"); return repo.save(maintenance); }

    @Override
    public Maintenance findById(Long id) { return repo.findById(id).orElseThrow(() ->
            new RuntimeException("Maintenance not found"));
    }

    @Scheduled(cron = "0 0 9 * * ?")
    public void checkAndAlertMaintenance(){
        LocalDate today = LocalDate.now() ;
        List<Maintenance> maintenances = repo.findAll().stream()
                .filter(m ->  m.getStatus().equalsIgnoreCase("PENDING") && !m.getScheduledAt().toLocalDate().isAfter(today))
                .collect(Collectors.toList());
        for(Maintenance maintenance : maintenances){
            String msg = "🚗 Maintenance due for Vehicle ID " + maintenance.getVehicle().getId()
                    + " scheduled on " + maintenance.getScheduledAt();
            System.out.println(msg);
            emailService.sendEmailNotification("sanketkumar.vaishya16663@sakec.ac.in" , "Maintenance Alert Email" , msg );
        }
    }
}
