package com.example.multi_tanent.warehouse.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private Double amount;
    private String method; // CASH, CARD, UPI, ONLINE
    private String status; // PENDING, COMPLETED, FAILED
    private LocalDateTime paidAt;


    @ManyToOne
    private Booking booking;
}
