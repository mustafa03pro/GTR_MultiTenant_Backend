package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.Company;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyRepository extends JpaRepository<Company , Long> {
}
