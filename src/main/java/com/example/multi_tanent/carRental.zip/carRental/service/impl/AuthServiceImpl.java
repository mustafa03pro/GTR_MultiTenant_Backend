package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.dto.AuthRequestDto;
import com.example.multi_tanent.warehouse.dto.AuthResponseDto;
import com.example.multi_tanent.warehouse.dto.RegisterRequestDto;
import com.example.multi_tanent.warehouse.model.Role;
import com.example.multi_tanent.warehouse.model.User;
import com.example.multi_tanent.warehouse.repository.RoleRepository;
import com.example.multi_tanent.warehouse.repository.UserRepository;

import com.example.multi_tanent.warehouse.service.AuthService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final com.example.multi_tanent.security.JwtUtil jwtUtil;

    public AuthServiceImpl(UserRepository userRepository, RoleRepository roleRepository,
            PasswordEncoder passwordEncoder, com.example.multi_tanent.security.JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    @Override
    public AuthResponseDto authenticate(AuthRequestDto request) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        java.util.List<String> roles = user.getRoles().stream().map(Role::getName)
                .collect(java.util.stream.Collectors.toList());
        String tenantId = com.example.multi_tanent.config.TenantContext.getTenantId();
        String token = jwtUtil.generateToken(user.getUsername(), tenantId, roles);

        return new AuthResponseDto(token);
    }

    @Override
    public AuthResponseDto register(RegisterRequestDto request) {
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new RuntimeException("User already exists");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setEmail(request.getEmail());
        user.setFullName(request.getFullName());
        user.setProfileCategory(request.getProfileCategory());
        user.setCommercialLicenseNumber(request.getCommercialLicenseNumber());
        user.setPhonePrimary(request.getPhonePrimary());
        user.setMobileSecondary(request.getMobileSecondary());
        user.setNationality(request.getNationality());
        user.setDrivingLicenseNumber(request.getDrivingLicenseNumber());
        user.setIdentityCardNo(request.getIdentityCardNo());
        user.setDateOfBirth(request.getDateOfBirth());
        user.setPassportNo(request.getPassportNo());
        user.setPassportIssuedDate(request.getPassportIssuedDate());
        user.setIdentityIssuedDate(request.getIdentityIssuedDate());
        user.setIdentityExpiryDate(request.getIdentityExpiryDate());

        // Default role assignment (flexible lookup)
        String requestedRole = (request.getRole() != null && !request.getRole().isEmpty()) ? request.getRole() : "USER";

        Role role = roleRepository.findByName(requestedRole)
                .or(() -> roleRepository.findByName("ROLE_" + requestedRole))
                .orElseThrow(() -> new RuntimeException(
                        "Role not found in DB (tried '" + requestedRole + "' and 'ROLE_" + requestedRole + "')"));

        user.setRoles(Set.of(role));
        userRepository.save(user);

        // Generate token with roles included
        java.util.List<String> roles = user.getRoles().stream().map(Role::getName)
                .collect(java.util.stream.Collectors.toList());
        String tenantId = com.example.multi_tanent.config.TenantContext.getTenantId();
        String token = jwtUtil.generateToken(user.getUsername(), tenantId, roles);

        return new AuthResponseDto(token);
    }

}
