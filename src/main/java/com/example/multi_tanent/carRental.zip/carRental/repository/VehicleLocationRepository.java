package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.VehicleLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VehicleLocationRepository extends JpaRepository<VehicleLocation, Long> {
    List<VehicleLocation> findByVehicleIdOrderByRecordedAtDesc(Long vehicleId);
}
