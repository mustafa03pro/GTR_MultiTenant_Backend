package com.example.multi_tanent.warehouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity
@Table(name = "vehicle_locations", indexes = {
        @Index(name = "idx_vehicle_ts", columnList = "vehicle_id, recorded_at")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "vehicle_id", nullable = false)
    private Long vehicleId;

    @Column(nullable = false)
    private Double latitude;

    @Column(nullable = false)
    private Double longitude;

    /**
     * When the device recorded this location. If device doesn't provide timestamp, server will set Instant.now().
     */
    @Column(name = "recorded_at", nullable = false)
    private Instant recordedAt;
}
