package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.dto.FineDto;
import com.example.multi_tanent.warehouse.dto.VehicleDto;
import com.example.multi_tanent.warehouse.service.RtaIntegrationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rta")
public class RtaController {

    private final RtaIntegrationService rtaService;

    public RtaController(RtaIntegrationService rtaService) {
        this.rtaService = rtaService;
    }

    @GetMapping("/vehicle")
    public ResponseEntity<VehicleDto> getVehicleDetails(@RequestParam String plateNumber) {
        VehicleDto vehicle = rtaService.getVehicleDetails(plateNumber);
        return ResponseEntity.ok(vehicle);
    }

    @GetMapping("/fines")
    public ResponseEntity<List<FineDto>> getSalikFines(@RequestParam String plateNumber) {
        List<FineDto> fines = rtaService.getSalikFinesByVehicle(plateNumber);
        return ResponseEntity.ok(fines);
    }
}
