package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Booking;
import com.example.multi_tanent.warehouse.model.BookingStatus;
import com.example.multi_tanent.warehouse.model.Customer;
import com.example.multi_tanent.warehouse.model.User;

import java.time.LocalDate;
import java.util.List;

public interface BookingService {
    Booking save(Booking booking);

    // updated: accept category (nullable) so service decides final category
    Booking createBooking(Booking booking, Long vehicleId, Customer customer, String category);

    List<Booking> getAllBookings();
    Booking getBookingById(Long id);
    void deleteBooking(Long id);
    Booking updateBookingStatus(Long bookingId, BookingStatus status);
    double calculateQuotation(Long vehicleId, LocalDate pickupDate, LocalDate returnDate);
    List<Booking> getBookingsByUser(User user);
    Booking completeBooking(Long BookingId) ;
}
