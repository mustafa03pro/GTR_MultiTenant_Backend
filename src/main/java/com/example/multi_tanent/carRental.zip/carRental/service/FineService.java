package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Fine;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface FineService {
    List<Fine> findAll();
    Fine create(Fine fine);
    Fine findById(Long id);
}
