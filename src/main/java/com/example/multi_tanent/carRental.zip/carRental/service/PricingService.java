package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Pricing;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PricingService {
    List<Pricing> findAll();
    Pricing create(Pricing pricing);
    Pricing findById(Long id);
    Pricing findByCategory(String category);
    Double getDiscountForCategory(String category);
    Double getExcessMileageCharge(Long pricingId);
    double calculateTotalPriceWithExtras(Long vehicleId, int rentalDays, double excessMiles, String category);
}
