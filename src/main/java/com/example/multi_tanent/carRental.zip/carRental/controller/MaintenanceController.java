package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.Maintenance;
import com.example.multi_tanent.warehouse.service.MaintenanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/maintenance")
public class MaintenanceController {
    private final MaintenanceService service;
    public MaintenanceController(MaintenanceService service) { this.service = service; }

    @GetMapping
    public ResponseEntity<List<Maintenance>> list() { return ResponseEntity.ok(service.findAll()); }

    @PostMapping
    public ResponseEntity<Maintenance> create(@RequestBody Maintenance m) { return ResponseEntity.ok(service.create(m)); }

    @GetMapping("/{id}")
    public ResponseEntity<Maintenance> get(@PathVariable Long id) { return ResponseEntity.ok(service.findById(id)); }
}
