package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Payment;
import com.stripe.exception.StripeException;

import java.util.List;
import java.util.Map;

public interface PaymentService {
    List<Payment> findAll();
    Payment findById(Long id);

    // 🔹 Stripe-specific methods
    Map<String, Object> createStripeSession(Map<String, Object> data) throws StripeException;
    Payment confirmStripePayment(Map<String, Object> data);
    Payment save(Payment payment);

}
