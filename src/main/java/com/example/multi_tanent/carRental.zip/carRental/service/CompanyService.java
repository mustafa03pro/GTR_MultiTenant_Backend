package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Company;

import java.util.List;

public interface CompanyService{
    Company createCompany(Company company);
    Company updateCompany(Long id, Company company);
    List<Company> getAllCompanies();
    Company getCompanyById(Long id);
    void deleteCompany(Long id);
}
