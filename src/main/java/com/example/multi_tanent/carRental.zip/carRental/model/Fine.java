package com.example.multi_tanent.warehouse.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

    @Entity
    @Table(name = "fines")
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public class Fine {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @ManyToOne
        private Booking booking;

        private Double amount;
        private String reason;
        private LocalDateTime issuedAt;
    }

