package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.exception.ResourceNotFoundException;
import com.example.multi_tanent.warehouse.model.Inspection;
import com.example.multi_tanent.warehouse.repository.InspectionRepository;
import com.example.multi_tanent.warehouse.service.FileStorageService;
import com.example.multi_tanent.warehouse.service.InspectionService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.util.ArrayList;
import java.util.List;

@Service
public class InspectionServiceImpl implements InspectionService {
    private final InspectionRepository inspectionRepository ;
    private final FileStorageService fileStorageService ;

    public InspectionServiceImpl(InspectionRepository inspectionRepository, FileStorageService fileStorageService) {
        this.inspectionRepository = inspectionRepository;
        this.fileStorageService = fileStorageService;
    }

    @Override
    public Inspection createInspection(Inspection inspection, List<MultipartFile> images) {
        List<String> imagePaths = saveInspectionImages(images) ;
        inspection.setImagePaths(imagePaths) ;
        return inspectionRepository.save(inspection) ;
    }

    private List<String> saveInspectionImages(List<MultipartFile> images) {
        List<String> imagePaths = new ArrayList<>();
        if (images != null) {
            for (MultipartFile image : images) {
                String filename = fileStorageService.storeFile(image);
                imagePaths.add(filename);
            }
        }
        return imagePaths;
    }

    @Override
    public Inspection findByBookingId(Long bookingId) {
        Inspection inspection = inspectionRepository.findByBookingId(bookingId) ;
        if(inspection == null){
            throw new ResourceNotFoundException("Inspection not found for booking id: " + bookingId);
        }
        return inspection ;
    }

    @Override
    public List<Inspection> getAllInspections() {
        return inspectionRepository.findAll();
    }

    @Override
    public Inspection updateInspection(Long id, Inspection inspection, List<MultipartFile> images) {
        Inspection existing = inspectionRepository.findById(id).
                orElseThrow(() -> new ResourceNotFoundException("Inspection not found with ID: " + id));

        existing.setFuelLevel(inspection.getFuelLevel());
        existing.setOdometerReading(inspection.getOdometerReading());
        existing.setDamages(inspection.getDamages());
        if (images != null && !images.isEmpty()) {
            List<String> imagesPaths = saveInspectionImages(images);
            existing.setImagePaths(inspection.getImagePaths());
        }
        return inspectionRepository.save(existing) ;
    }
}
