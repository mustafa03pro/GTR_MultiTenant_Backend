//package com.example.multi_tanent.warehouse.service;
package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.model.User;
import com.example.multi_tanent.warehouse.repository.UserRepository;
import com.example.multi_tanent.warehouse.service.UserService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public User createUser(User user) {
        // You can add validation and password encoding here
        return userRepository.save(user);
    }

    @Override
    public User updateUser(Long id, User userDetails) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id " + id));

        // Update allowed fields
        user.setUsername(userDetails.getUsername());
        user.setEmail(userDetails.getEmail());
        user.setFullName(userDetails.getFullName());
        user.setProfileCategory(userDetails.getProfileCategory());
        user.setPhonePrimary(userDetails.getPhonePrimary());
        user.setNationality(userDetails.getNationality());
        user.setDrivingLicenseNumber(userDetails.getDrivingLicenseNumber());
        user.setIdentityCardNo(userDetails.getIdentityCardNo());
        user.setDateOfBirth(userDetails.getDateOfBirth());
        user.setPassportNo(userDetails.getPassportNo());
        user.setPassportIssuedDate(userDetails.getPassportIssuedDate());
        user.setIdentityIssuedDate(userDetails.getIdentityIssuedDate());
        user.setIdentityExpiryDate(userDetails.getIdentityExpiryDate());
        user.setMobileSecondary(userDetails.getMobileSecondary());
        user.setCommercialLicenseNumber(userDetails.getCommercialLicenseNumber());

        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new RuntimeException("User not found with id " + id);
        }
        userRepository.deleteById(id);
    }
}
