package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.dto.AuthRequestDto;
import com.example.multi_tanent.warehouse.dto.AuthResponseDto;
import com.example.multi_tanent.warehouse.dto.RegisterRequestDto;

public interface AuthService {
    AuthResponseDto authenticate(AuthRequestDto request);
    AuthResponseDto register(RegisterRequestDto request);
}
