package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Vehicle;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class VehicleLocationBroadcastService {

    private final SimpMessagingTemplate messagingTemplate;

    public VehicleLocationBroadcastService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    // broadcast all
    public void broadcastLocation(Vehicle vehicle) {
        messagingTemplate.convertAndSend("/topic/locations", vehicle);

        messagingTemplate.convertAndSend("/topic/vehicle/" + vehicle.getId(), vehicle);
    }
}
