package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.Fine;
import com.example.multi_tanent.warehouse.service.FineService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fines")
public class FineController {
    private final FineService service;
    public FineController(FineService service) { this.service = service; }

    @GetMapping
    public ResponseEntity<List<Fine>> list() { return ResponseEntity.ok(service.findAll()); }

    @PostMapping
    public ResponseEntity<Fine> create(@RequestBody Fine f) { return ResponseEntity.ok(service.create(f)); }

    @GetMapping("/{id}")
    public ResponseEntity<Fine> get(@PathVariable Long id) { return ResponseEntity.ok(service.findById(id)); }
}
