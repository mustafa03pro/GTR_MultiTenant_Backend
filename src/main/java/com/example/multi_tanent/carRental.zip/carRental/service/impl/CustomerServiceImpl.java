package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.exception.ResourceNotFoundException;
import com.example.multi_tanent.warehouse.model.Customer;
import com.example.multi_tanent.warehouse.repository.CustomerRepository;
import com.example.multi_tanent.warehouse.service.CustomerService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public Customer createCustomer(Customer customer) {
        if(customerRepository.existsByEmail(customer.getEmail())){
            // Instead of throwing, fetch the existing customer to avoid wrong ID
            return customerRepository.findByEmail(customer.getEmail())
                    .orElseThrow(() -> new RuntimeException("Customer exists but not found"));
        }
        return customerRepository.save(customer);
    }


    @Override
    public Customer updateCustomer(Long id, Customer customer) {
        Customer existing = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with ID: " + id));

        existing.setProfileType(customer.getProfileType());
        existing.setProfileCategory(customer.getProfileCategory());
        existing.setPreferredLanguage(customer.getPreferredLanguage());
        existing.setFullNameEnglish(customer.getFullNameEnglish());
        existing.setGender(customer.getGender());
        existing.setNationality(customer.getNationality());
        existing.setDateOfBirth(customer.getDateOfBirth());
        existing.setPlaceOfBirth(customer.getPlaceOfBirth());
        existing.setIdentityCardNo(customer.getIdentityCardNo());
        existing.setPhone(customer.getPhone());
        existing.setHomeAddress(customer.getHomeAddress());
        existing.setHomePhone(customer.getHomePhone());
        existing.setWorkAddress(customer.getWorkAddress());
        existing.setProfession(customer.getProfession());
        existing.setEmail(customer.getEmail());
        existing.setLicenseNumber(customer.getLicenseNumber());
        existing.setDrivingLicenseIssuedBy(customer.getDrivingLicenseIssuedBy());
        existing.setDrivingLicenseIssuedDate(customer.getDrivingLicenseIssuedDate());
        existing.setDrivingLicenseExpiryDate(customer.getDrivingLicenseExpiryDate());
        existing.setPassportNo(customer.getPassportNo());
        existing.setPassportIssuedDate(customer.getPassportIssuedDate());
        existing.setPassportExpiryDate(customer.getPassportExpiryDate());
        existing.setMobile(customer.getMobile());
        existing.setMotherName(customer.getMotherName());

        return customerRepository.save(existing);
    }


    @Override
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    @Override
    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with ID: " + id));
    }

    @Override
    public Customer getCustomerByEmail(String email) {
        return customerRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with email: " + email));
    }

    @Override
    public void deleteCustomer(Long id) {
        if (!customerRepository.existsById(id)) {
            throw new ResourceNotFoundException("Customer not found with ID: " + id);
        }
        customerRepository.deleteById(id);
    }
}
