package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Maintenance;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface MaintenanceService {
    List<Maintenance> findAll();
    Maintenance create(Maintenance maintenance);
    Maintenance findById(Long id);
}
