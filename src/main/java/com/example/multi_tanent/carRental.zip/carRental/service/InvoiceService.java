package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Booking;
import com.example.multi_tanent.warehouse.model.Invoice;
import com.example.multi_tanent.warehouse.model.Payment;

import java.util.List;
import java.util.Optional;

public interface InvoiceService {
    List<Invoice> findAll();
    Invoice create(Invoice invoice);
    Invoice findById(Long id);
    Optional<Invoice> findByBookingId(Long bookingId);
    Invoice createInvoiceForBooking(Booking booking, Payment payment);
    byte[] generateInvoicePdf(Long bookingId) ;
}
