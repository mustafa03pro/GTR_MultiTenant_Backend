package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.dto.FineDto;
import com.example.multi_tanent.warehouse.dto.VehicleDto;
import com.example.multi_tanent.warehouse.service.RtaIntegrationService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

@Service
@Slf4j
public class RtaIntegrationServiceImpl implements RtaIntegrationService {

    @Value("${rta.clientId}")
    private String clientId;

    @Value("${rta.clientSecret}")
    private String clientSecret;

    @Value("${rta.tenantId}")
    private String tenantId;

    @Value("${rta.base-url}")
    private String apiBaseUrl;

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    private volatile String cachedToken;
    private volatile Instant tokenExpiry;
    private final ReentrantLock tokenLock = new ReentrantLock();

    public RtaIntegrationServiceImpl(RestTemplate restTemplate, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
    }

    // =======================
    // 1️⃣ Get Access Token
    // =======================
    @Override
    public String getAccessToken() {
        // Use cached token if valid
        if (cachedToken != null && tokenExpiry != null && Instant.now().isBefore(tokenExpiry.minusSeconds(30))) {
            log.info("🔄 Using cached RTA access token (valid until {})", tokenExpiry);
            return cachedToken;
        }

        tokenLock.lock();
        try {
            // Double-check after acquiring the lock
            if (cachedToken != null && tokenExpiry != null && Instant.now().isBefore(tokenExpiry.minusSeconds(30))) {
                log.info("🔄 Using cached RTA access token (valid until {})", tokenExpiry);
                return cachedToken;
            }

            String tokenUrl = String.format(
                    "%s/information-management/%s/integrations/get-api-token",
                    apiBaseUrl,
                    tenantId
            );

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            log.info("🌐 Requesting new RTA token from URL: {}", tokenUrl);
            ResponseEntity<String> response = restTemplate.exchange(tokenUrl, HttpMethod.GET, entity, String.class);

            log.info("🔹 Token API Status: {}", response.getStatusCode());
            log.info("🔹 Token API Response Body: {}", response.getBody());

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new RuntimeException("Failed to obtain RTA token: " + response.getStatusCode());
            }

            if (response.getBody() == null || response.getBody().isEmpty()) {
                throw new RuntimeException("Empty response received from RTA token endpoint");
            }

            JsonNode root = objectMapper.readTree(response.getBody());
            String token = root.path("access_token").asText(null);
            long expiresIn = root.path("expires_in").asLong(900);

            if (token == null || token.isBlank()) {
                throw new RuntimeException("RTA token missing from response");
            }

            cachedToken = token;
            tokenExpiry = Instant.now().plusSeconds(expiresIn);

            log.info("✅ RTA token obtained successfully: {} (expires in {} seconds)", cachedToken, expiresIn);
            return cachedToken;

        } catch (Exception e) {
            log.error("❌ Failed to fetch RTA token", e);
            throw new RuntimeException("Failed to fetch RTA access token", e);
        } finally {
            tokenLock.unlock();
        }
    }

    // =======================
    // 2️⃣ Get Salik Fines
    // =======================
    @Override
    public List<FineDto> getSalikFinesByVehicle(String plateNumber) {
        String token = getAccessToken();
        String url = String.format("%s/salik/fines/%s", apiBaseUrl, plateNumber);

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Void> entity = new HttpEntity<>(headers);
        List<FineDto> fines = new ArrayList<>();

        try {
            log.info("🌐 Fetching Salik fines for vehicle: {}", plateNumber);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

            log.info("🔹 Salik Fines API Status: {}", response.getStatusCode());
            log.info("🔹 Salik Fines Response Body: {}", response.getBody());

            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                throw new RuntimeException("Failed to fetch fines: " + response.getStatusCode());
            }

            JsonNode root = objectMapper.readTree(response.getBody());
            JsonNode finesArray = root.path("fines");

            if (finesArray.isMissingNode() || !finesArray.isArray()) {
                log.warn("⚠️ No fines found for plate number: {}", plateNumber);
                return fines;
            }

            for (JsonNode item : finesArray) {
                FineDto fine = FineDto.builder()
                        .amount(item.path("amount").asDouble(0.0))
                        .reason(item.path("description").asText("Unknown"))
                        .issuedAt(LocalDateTime.parse(
                                item.path("date").asText("2025-01-01T00:00:00Z"),
                                DateTimeFormatter.ISO_DATE_TIME
                        ))
                        .build();
                fines.add(fine);
            }

            log.info("✅ Retrieved {} Salik fines for plate number {}", fines.size(), plateNumber);
            return fines;

        } catch (Exception e) {
            log.error("❌ Failed to fetch or parse Salik fines for {}", plateNumber, e);
            throw new RuntimeException("Error fetching Salik fines from RTA API", e);
        }
    }

    // =======================
    // 3️⃣ Get Vehicle Details
    // =======================
    @Override
    public VehicleDto getVehicleDetails(String plateNumber) {
        String token = getAccessToken();
        String url = String.format("%s/vehicle?plateNumber=%s", apiBaseUrl, plateNumber);

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        try {
            log.info("🌐 Fetching vehicle details from URL: {}", url);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

            log.info("🔹 Vehicle Details API Status: {}", response.getStatusCode());
            log.info("🔹 Vehicle Details Response Body: {}", response.getBody());

            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                throw new RuntimeException("Failed to fetch vehicle details: " + response.getStatusCode());
            }

            JsonNode root = objectMapper.readTree(response.getBody());
            VehicleDto vehicle = new VehicleDto();
            vehicle.setPlateNumber(root.path("plateNumber").asText(null));
            vehicle.setMake(root.path("make").asText(null));
            vehicle.setModel(root.path("model").asText(null));
            vehicle.setYear(root.path("year").asInt(0));
            vehicle.setStatus(root.path("status").asText("Available"));

            log.info("✅ Vehicle details fetched successfully for plate number {}", plateNumber);
            return vehicle;

        } catch (Exception e) {
            log.error("❌ Failed to fetch vehicle details from RTA for {}", plateNumber, e);
            throw new RuntimeException("Error fetching vehicle details from RTA API", e);
        }
    }


}
