package com.example.multi_tanent.warehouse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StripeResponseDto {
    private String status ;
    private String message ;
    private String sessionId ;
    private String sessionUrl ;
}
