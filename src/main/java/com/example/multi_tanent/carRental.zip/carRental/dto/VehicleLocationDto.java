package com.example.multi_tanent.warehouse.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for receiving GPS location updates.
 * timestamp is optional (milliseconds since epoch) — if provided you can use it; otherwise server will set recordedAt.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleLocationDto {
    @NotNull(message = "latitude is required")
    private Double latitude;

    @NotNull(message = "longitude is required")
    private Double longitude;

    // Optional epoch millis from device
    private Long timestamp;
}
