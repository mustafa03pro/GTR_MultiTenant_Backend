package com.example.multi_tanent.warehouse.dto;

import lombok.Data;

@Data
public class AuthRequestDto {
    private String username;
    private String password;
}
