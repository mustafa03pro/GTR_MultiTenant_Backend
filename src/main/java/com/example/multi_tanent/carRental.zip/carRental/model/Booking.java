package com.example.multi_tanent.warehouse.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "bookings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "vehicle_id", nullable = false)
    @JsonIgnoreProperties({"bookings"})
    private Vehicle vehicle;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    @JsonIgnoreProperties({"bookings"})
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnoreProperties({"bookings", "roles"})
    private User user;

    private LocalDate pickupDate;
    private LocalDate returnDate;
    private String pickupLocation;
    private String dropLocation;
    private int rentalDays;
    private Double totalPrice;
    private Double extraAmount = 0.0; // 🆕 Added field

    @Enumerated(EnumType.STRING)
    private BookingStatus status; // BOOKED, CANCELLED, COMPLETED

    private Double startOdometer;     // set on booking start
    private Double endOdometer;       // set on booking completion
    private Double totalKmsDriven;    // computed at end
    private Double extraKmCharges;    // computed at end

}
