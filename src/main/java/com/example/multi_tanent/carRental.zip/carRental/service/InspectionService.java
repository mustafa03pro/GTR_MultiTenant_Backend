package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.model.Inspection;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface InspectionService {
    Inspection createInspection(Inspection inspection , List<MultipartFile> images) ;
    Inspection findByBookingId(Long bookingId) ;
    List<Inspection> getAllInspections() ;
    Inspection updateInspection(Long id , Inspection inspection , List<MultipartFile> images) ;

}
