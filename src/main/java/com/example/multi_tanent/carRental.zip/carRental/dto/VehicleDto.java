package com.example.multi_tanent.warehouse.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
import java.util.List;

@Data
public class VehicleDto {

    private Long id;

    @NotBlank(message = "Vehicle plate number is mandatory")
    private String plateNumber; // Vehicle Plate Number

    @DecimalMin(value = "0.0", inclusive = true, message = "Daily rate should be non-negative")
    private Double dailyRate;

    @DecimalMin(value = "0.0", inclusive = true, message = "Weekly rate should be non-negative")
    private Double weeklyRate;

    @DecimalMin(value = "0.0", inclusive = true, message = "Yearly rate should be non-negative")
    private Double monthlyRate; // Vehicle Monthly Rate

    @DecimalMin(value = "0.0", inclusive = true, message = "Yearly rate should be non-negative")
    private Double yearlyRate; // Vehicle Yearly Rate

    @NotNull(message = "License issuance date is required")
    private LocalDate licenseIssuanceDate; // Vehicle License Issuance Date

    @NotNull(message = "License expiry date is required")
    private LocalDate licenseExpiryDate; // Vehicle License Expiry Date

    @NotBlank(message = "Current location is required")
    private String currentLocation; // Vehicle Current Location

    @NotBlank(message = "Status is required")
    private String status; // Vehicle Current Status (e.g. Available, Rented, Maintenance)

    @NotBlank(message = "Salik account is required")
    private String salikAccount; // Vehicle Salik Account

    @NotBlank(message = "Plate category is required")
    private String plateCategory; // Vehicle Plate Category

    // ✅ Categories can have multiple selections like SUV, Sedan, Hatchback, etc.
    @NotEmpty(message = "At least one category must be selected")
    private List<String> vehicleCategories; // Vehicle Categories (checkbox list)

    // Optional / Additional details for completeness
    @NotBlank(message = "Make is mandatory")
    private String make;

    @NotBlank(message = "Model is mandatory")
    private String model;

    @NotBlank(message = "Engine is mandatory")
    private String engine;

    @Min(value = 1900, message = "Year must be greater than or equal to 1900")
    private Integer year;

    @NotBlank(message = "Color is mandatory")
    private String color;

    @DecimalMin(value = "0.0", inclusive = true, message = "Current odometer should be non-negative")
    private Double currentOdometer = 0.0;

    @DecimalMin(value = "0.0", inclusive = true, message = "Kms limit should be non-negative")
    private Double kmsLimit;

    @DecimalMin(value = "0.0", inclusive = true, message = "Extra km charge should be non-negative")
    private Double extraKmCharge;

    @DecimalMin(value = "0.0", inclusive = true, message = "Daily odometer limit should be non-negative")
    private Double dailyOdometerLimit;

    @DecimalMin(value = "0.0", inclusive = true, message = "Odometer extra fees per unit should be non-negative")
    private Double odometerExtraFeesPerUnit;

    @DecimalMin(value = "0.0", inclusive = true, message = "Current fuel should be non-negative")
    private Double currentFuel;

    private String insuranceProviderName;

    private String lastKnownAddress;
    private String imageUrl;
}
