package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.model.Booking;
import com.example.multi_tanent.warehouse.model.Invoice;
import com.example.multi_tanent.warehouse.model.Payment;
import com.example.multi_tanent.warehouse.repository.InvoiceRepository;
import com.example.multi_tanent.warehouse.service.InvoiceService;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository repo;

    public InvoiceServiceImpl(InvoiceRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<Invoice> findAll() {
        System.out.println("📜 [DEBUG] Fetching all invoices...");
        return repo.findAll();
    }

    @Override
    public Invoice create(Invoice invoice) {
        invoice.setInvoiceNumber("INV-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        invoice.setIssuedAt(LocalDateTime.now());
        System.out.println("🧾 [DEBUG] Creating manual invoice: " + invoice.getInvoiceNumber());
        return repo.save(invoice);
    }

    @Override
    public Invoice findById(Long id) {
        System.out.println("🔍 [DEBUG] Searching invoice by ID: " + id);
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("❌ Invoice not found with ID: " + id));
    }

    @Override
    public Optional<Invoice> findByBookingId(Long bookingId) {
        System.out.println("🔍 [DEBUG] Searching invoice by Booking ID: " + bookingId);
        return repo.findByBooking_Id(bookingId);
    }

    @Override
    @Transactional
    public Invoice createInvoiceForBooking(Booking booking, Payment payment) {
        Long bookingId = booking.getId();
        System.out.println("🧾 [DEBUG] Creating invoice for Booking ID: " + bookingId);

        Optional<Invoice> existingInvoice = repo.findByBooking_Id(bookingId);
        if (existingInvoice.isPresent()) {
            System.out.println("⚠️ [INFO] Invoice already exists for Booking ID: " + bookingId);
            return existingInvoice.get();
        }

        double totalAmount = (booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0)
                + (booking.getExtraAmount() != null ? booking.getExtraAmount() : 0.0);

        try {
            Invoice invoice = new Invoice();
            invoice.setBooking(booking);
            invoice.setPayment(payment);
            invoice.setAmount(totalAmount);
            invoice.setStatus(payment != null ? payment.getStatus() : "PENDING");
            invoice.setIssuedAt(LocalDateTime.now());
            invoice.setInvoiceNumber("INV-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());

            Invoice saved = repo.save(invoice);
            System.out.println("✅ [SUCCESS] Invoice created → Total ₹" + totalAmount);
            return saved;
        } catch (DataIntegrityViolationException e) {
            System.out.println("❌ [ERROR] Duplicate invoice detected: " + e.getMessage());
            throw new RuntimeException("Invoice already exists for this booking.");
        } catch (Exception e) {
            System.out.println("❌ [ERROR] Invoice save failed: " + e.getMessage());
            throw new RuntimeException("Failed to create invoice: " + e.getMessage());
        }
    }

    @Override
    public byte[] generateInvoicePdf(Long bookingId) {
        Optional<Invoice> optionalInvoice = repo.findByBooking_Id(bookingId);
        if (optionalInvoice.isEmpty()) {
            throw new RuntimeException("Invoice not found for Booking ID: " + bookingId);
        }

        Invoice invoice = optionalInvoice.get();
        Booking booking = invoice.getBooking();
        Payment payment = invoice.getPayment();

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, out);
            document.open();

            // 🧾 Header
            Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
            Font smallFont = new Font(Font.HELVETICA, 10);
            Font labelFont = new Font(Font.HELVETICA, 12, Font.BOLD);

            Paragraph title = new Paragraph("Car Rental Invoice", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph("Generated on: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm")), smallFont));
            document.add(new Paragraph("\n"));

            // 🧾 Invoice Details Table
            PdfPTable invoiceTable = new PdfPTable(2);
            invoiceTable.setWidthPercentage(100);
            invoiceTable.addCell(new PdfPCell(new Phrase("Invoice Number", labelFont)));
            invoiceTable.addCell(new PdfPCell(new Phrase(invoice.getInvoiceNumber())));
            invoiceTable.addCell(new PdfPCell(new Phrase("Status", labelFont)));
            invoiceTable.addCell(new PdfPCell(new Phrase(invoice.getStatus())));
            invoiceTable.addCell(new PdfPCell(new Phrase("Issued At", labelFont)));
            invoiceTable.addCell(new PdfPCell(new Phrase(invoice.getIssuedAt().format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm")))));
            document.add(invoiceTable);
            document.add(new Paragraph("\n"));

            // 🚗 Booking Details
            document.add(new Paragraph("Booking Details", labelFont));
            PdfPTable bookingTable = new PdfPTable(2);
            bookingTable.setWidthPercentage(100);
            bookingTable.addCell("Booking ID");
            bookingTable.addCell(String.valueOf(booking.getId()));
            bookingTable.addCell("Vehicle");
            bookingTable.addCell(booking.getVehicle() != null
                    ? booking.getVehicle().getMake() + " " + booking.getVehicle().getModel()
                    : "N/A");
            bookingTable.addCell("Pickup Date");
            bookingTable.addCell(booking.getPickupDate() != null ? booking.getPickupDate().toString() : "—");
            bookingTable.addCell("Return Date");
            bookingTable.addCell(booking.getReturnDate() != null ? booking.getReturnDate().toString() : "—");
            bookingTable.addCell("Pickup Location");
            bookingTable.addCell(booking.getPickupLocation());
            bookingTable.addCell("Drop Location");
            bookingTable.addCell(booking.getDropLocation());
            document.add(bookingTable);
            document.add(new Paragraph("\n"));

            // 💰 Payment Summary
            document.add(new Paragraph("Payment Summary", labelFont));
            PdfPTable paymentTable = new PdfPTable(2);
            paymentTable.setWidthPercentage(100);
            paymentTable.addCell("Car Rent");
            paymentTable.addCell("₹" + (booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0));
            paymentTable.addCell("Extra Charges");
            paymentTable.addCell("₹" + (booking.getExtraAmount() != null ? booking.getExtraAmount() : 0.0));
            paymentTable.addCell("Total Amount");
            paymentTable.addCell("₹" + invoice.getAmount());
            if (payment != null) {
                paymentTable.addCell("Payment ID");
                paymentTable.addCell(String.valueOf(payment.getId()));
                paymentTable.addCell("Payment Status");
                paymentTable.addCell(payment.getStatus());
            }
            document.add(paymentTable);

            // Footer
            document.add(new Paragraph("\nThank you for choosing CarRental Services!", smallFont));
            document.add(new Paragraph("For support, contact support@carrental.com", smallFont));

            document.close();
            System.out.println("📄 [INFO] Invoice PDF generated for booking ID: " + bookingId);
            return out.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to generate invoice PDF: " + e.getMessage());
        }
    }
}
