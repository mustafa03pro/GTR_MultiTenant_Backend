package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.dto.VehicleLocationDto;
import com.example.multi_tanent.warehouse.model.Vehicle;
import com.example.multi_tanent.warehouse.service.VehicleLocationBroadcastService;
import com.example.multi_tanent.warehouse.service.VehicleService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller for updating and broadcasting vehicle locations.
 *
 * Endpoint:
 *   POST /api/vehicles/{id}/location
 *
 * Sample Request Body:
 * {
 *   "latitude": 19.120,
 *   "longitude": 72.850,
 *   "timestamp": "2025-11-01T12:35:00Z"
 * }
 */
@RestController
@RequestMapping("/api/vehicles")
@CrossOrigin(origins = "*") // 🔹 Ensures your frontend (React) can access it directly
public class VehicleLocationController {

    private static final Logger log = LoggerFactory.getLogger(VehicleLocationController.class);

    private final VehicleService vehicleService;
    private final VehicleLocationBroadcastService broadcaster;

    public VehicleLocationController(VehicleService vehicleService,
                                     VehicleLocationBroadcastService broadcaster) {
        this.vehicleService = vehicleService;
        this.broadcaster = broadcaster;
    }

    /**
     * Updates the location of a specific vehicle and broadcasts the change
     * via WebSocket to all connected clients.
     */
    @PostMapping("/{id}/location")
    public ResponseEntity<?> updateLocation(
            @PathVariable Long id,
            @Valid @RequestBody VehicleLocationDto locationDto) {
        try {
            log.info("📍 Updating vehicle #{} location: lat={}, lng={}",
                    id, locationDto.getLatitude(), locationDto.getLongitude());

            Vehicle updated = vehicleService.updateVehicleLocation(
                    id,
                    locationDto.getLatitude(),
                    locationDto.getLongitude(),
                    null,
                    locationDto.getTimestamp()
            );

            // ✅ Broadcast location update to WebSocket subscribers
            broadcaster.broadcastLocation(updated);
            log.info("✅ Vehicle #{} location broadcasted successfully", id);

            return ResponseEntity.ok(updated);

        } catch (Exception e) {
            log.error("❌ Failed to update location for vehicle #{}: {}", id, e.getMessage(), e);
            return ResponseEntity
                    .internalServerError()
                    .body("Failed to update vehicle location: " + e.getMessage());
        }
    }
}
