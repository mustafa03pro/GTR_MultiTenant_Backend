package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.dto.AuthRequestDto;
import com.example.multi_tanent.warehouse.dto.AuthResponseDto;
import com.example.multi_tanent.warehouse.dto.RegisterRequestDto;
import com.example.multi_tanent.warehouse.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponseDto> login(@RequestBody AuthRequestDto authRequestDto) {
        AuthResponseDto responseDto = authService.authenticate(authRequestDto);
        return ResponseEntity.ok(responseDto);
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponseDto> register(@RequestBody RegisterRequestDto registerRequestDto){
        AuthResponseDto responseDto = authService.register(registerRequestDto);
        return ResponseEntity.ok(responseDto);
    }
}
