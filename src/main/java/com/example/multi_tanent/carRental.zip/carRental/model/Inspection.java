package com.example.multi_tanent.warehouse.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "inspections")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Inspection {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id ;

    @OneToOne
    @JoinColumn(name = "booking_id" , unique = true)
    private Booking booking ;

    private double fuelLevel;
    private double odometerReading;

    @Column(length = 1000)
    private String damages;

    @ElementCollection
    @CollectionTable(name = "inspection_images", joinColumns = @JoinColumn(name = "inspection_id"))
    @Column(name = "image_path")
    private List<String> imagePaths;
}

