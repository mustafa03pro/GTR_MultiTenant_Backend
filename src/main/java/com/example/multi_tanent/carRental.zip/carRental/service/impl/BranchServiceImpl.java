package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.model.Branch;
import com.example.multi_tanent.warehouse.repository.BranchRepository;
import com.example.multi_tanent.warehouse.service.BranchService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BranchServiceImpl implements BranchService {
    private final BranchRepository repo;

    public BranchServiceImpl(BranchRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<Branch> findAll() {
        return repo.findAll();
    }

    @Override
    public Branch save(Branch branch) {
        return repo.save(branch);
    }

    @Override
    public Branch findById(Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Branch not found"));
    }
}
