package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.Pricing;
import com.example.multi_tanent.warehouse.service.PricingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pricing")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class PricingController {

    private final PricingService service;

    public PricingController(PricingService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Pricing>> list() {
        return ResponseEntity.ok(service.findAll());
    }

    @PostMapping
    public ResponseEntity<Pricing> create(@RequestBody Pricing p) {
        return ResponseEntity.ok(service.create(p));
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<Pricing> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    // ✅ NEW: Get pricing by category name
    @GetMapping("/category/{category}")
    public ResponseEntity<Pricing> getByCategory(@PathVariable String category) {
        Pricing pricing = service.findByCategory(category);
        return ResponseEntity.ok(pricing);
    }
}
