package com.example.multi_tanent.warehouse.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class RegisterRequestDto {
    private String fullName;
    private String username;
    private String password;
    private String email;
    private String role; // e.g., "ROLE_USER" or "ROLE_ADMIN"

    // Additional fields for registration

    private String profileCategory; // Individual, Commercial
    private String commercialLicenseNumber;

    private String phonePrimary;
    private String mobileSecondary;

    private String nationality;

    private String drivingLicenseNumber;
    private String identityCardNo;

    private LocalDate dateOfBirth;

    private String passportNo;
    private LocalDate passportIssuedDate;

    private LocalDate identityIssuedDate;
    private LocalDate identityExpiryDate;
}
