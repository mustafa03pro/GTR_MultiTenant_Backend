package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.exception.ResourceNotFoundException;
import com.example.multi_tanent.warehouse.model.Vehicle;
import com.example.multi_tanent.warehouse.model.VehicleLocation;
import com.example.multi_tanent.warehouse.repository.VehicleLocationRepository;
import com.example.multi_tanent.warehouse.repository.VehicleRepository;
import com.example.multi_tanent.warehouse.service.VehicleService;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository vehicleRepository;
    private final VehicleLocationRepository vehicleLocationRepository;

    private static final double EARTH_RADIUS_KM = 6371.0; // Earth's radius in KM

    public VehicleServiceImpl(VehicleRepository vehicleRepository,
                              VehicleLocationRepository vehicleLocationRepository) {
        this.vehicleRepository = vehicleRepository;
        this.vehicleLocationRepository = vehicleLocationRepository;
    }

    // ------------------ VEHICLE CRUD ------------------

    @Override
    public List<Vehicle> findAll() {
        return vehicleRepository.findAll();
    }

    @Override
    public Vehicle save(Vehicle vehicle) {
        vehicle.setStatus("AVAILABLE");
        vehicle.setCurrentOdometer(0.0);
        return vehicleRepository.save(vehicle);
    }

    @Override
    public Vehicle findById(Long id) {
        return vehicleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with id " + id));
    }

    @Override
    public Vehicle updateVehicleDetails(Long id, Vehicle vehicle) {
        Vehicle existing = findById(id);

        existing.setPlateNumber(vehicle.getPlateNumber());
        existing.setMake(vehicle.getMake());
        existing.setModel(vehicle.getModel());
        existing.setEngine(vehicle.getEngine());
        existing.setYear(vehicle.getYear());
        existing.setColor(vehicle.getColor());
        existing.setDailyRate(vehicle.getDailyRate());
        existing.setWeeklyRate(vehicle.getWeeklyRate());
        existing.setMonthlyRate(vehicle.getMonthlyRate());
        existing.setYearlyRate(vehicle.getYearlyRate());
        existing.setLicenseIssuanceDate(vehicle.getLicenseIssuanceDate());
        existing.setLicenseExpiryDate(vehicle.getLicenseExpiryDate());
        existing.setInsuranceExpiryDate(vehicle.getInsuranceExpiryDate());
        existing.setInsuranceProviderName(vehicle.getInsuranceProviderName());
        existing.setCurrentLocation(vehicle.getCurrentLocation());
        existing.setStatus(vehicle.getStatus());
        existing.setLastKnownAddress(vehicle.getLastKnownAddress());
        existing.setCurrentOdometer(0.0);
        existing.setDailyOdometerLimit(vehicle.getDailyOdometerLimit());
        existing.setOdometerExtraFeesPerUnit(vehicle.getOdometerExtraFeesPerUnit());
        existing.setCurrentFuel(vehicle.getCurrentFuel());
        existing.setPlateCategory(vehicle.getPlateCategory());
        existing.setSalikAccount(vehicle.getSalikAccount());
        existing.setCategory(vehicle.getCategory());
        existing.setVehicleCategories(vehicle.getVehicleCategories());
        existing.setImageUrl(vehicle.getImageUrl());
        existing.setKmsLimit(vehicle.getKmsLimit());
        existing.setExtraKmCharge(vehicle.getExtraKmCharge());
        return vehicleRepository.save(existing);
    }

    @Override
    public List<Vehicle> findByStatus(String status) {
        return vehicleRepository.findByStatus(status);
    }

    @Override
    public void deleteById(Long id) {
        Vehicle vehicle = findById(id);
        vehicleRepository.delete(vehicle);
    }

    // ------------------ GPS & KMS TRACKING ------------------

    private static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS_KM * c;
    }

    @Override
    @Transactional
    public Vehicle updateVehicleLocation(Long id, Double latitude, Double longitude, String address, Long timestamp) {
        Vehicle vehicle = findById(id);

        List<VehicleLocation> recentLocations = vehicleLocationRepository.findByVehicleIdOrderByRecordedAtDesc(id);
        VehicleLocation lastLocation = recentLocations.isEmpty() ? null : recentLocations.get(0);

        double distanceKm = 0.0;

        // Calculate distance using previous location if available
        if (lastLocation != null && lastLocation.getLatitude() != null && lastLocation.getLongitude() != null) {
            distanceKm = haversineKm(lastLocation.getLatitude(), lastLocation.getLongitude(), latitude, longitude);
        }

        // Ignore small GPS drifts
        if (distanceKm >= 0.05) {
            double currentOdo = (vehicle.getCurrentOdometer() != null) ? vehicle.getCurrentOdometer() : 0.0;
            vehicle.setCurrentOdometer(currentOdo + distanceKm);
        }

        // ✅ Check for exceeding daily odometer limit
        double extraKm = 0.0;
        double extraCharge = 0.0;

        if (vehicle.getDailyOdometerLimit() != null && vehicle.getOdometerExtraFeesPerUnit() != null) {
            double limit = vehicle.getDailyOdometerLimit();
            double current = vehicle.getCurrentOdometer();

            if (current > limit) {
                extraKm = current - limit;
                extraCharge = extraKm * vehicle.getOdometerExtraFeesPerUnit();
                vehicle.setExtraKm(extraKm);
                vehicle.setExtraCharge(extraCharge);

                System.out.printf(
                        "⚠️ Vehicle %s exceeded daily limit: %.2f KM extra. Extra charge: %.2f%n",
                        vehicle.getPlateNumber(), extraKm, extraCharge
                );
            } else {
                vehicle.setExtraKm(0.0);
                vehicle.setExtraCharge(0.0);
            }
        }

        // Update current GPS position
        vehicle.setLatitude(latitude);
        vehicle.setLongitude(longitude);
        if (address != null && !address.isEmpty()) {
            vehicle.setLastKnownAddress(address);
        }

        Vehicle savedVehicle = vehicleRepository.save(vehicle);

        // Save GPS history
        Instant recordedAt = (timestamp != null) ? Instant.ofEpochMilli(timestamp) : Instant.now();
        VehicleLocation location = VehicleLocation.builder()
                .vehicleId(savedVehicle.getId())
                .latitude(latitude)
                .longitude(longitude)
                .recordedAt(recordedAt)
                .build();

        vehicleLocationRepository.save(location);

        // Set transient values for response
        savedVehicle.setExtraKm(extraKm);
        savedVehicle.setExtraCharge(extraCharge);

        return savedVehicle;
    }

    @Override
    public void incrementOdometer(Long id, double kms) {
        Vehicle vehicle = findById(id);
        double current = (vehicle.getCurrentOdometer() != null) ? vehicle.getCurrentOdometer() : 0.0;
        vehicle.setCurrentOdometer(current + kms);
        vehicleRepository.save(vehicle);
    }
}
