package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle , Long> {
    List<Vehicle> findByStatus(String status);
}
