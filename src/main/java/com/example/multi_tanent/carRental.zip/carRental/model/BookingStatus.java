package com.example.multi_tanent.warehouse.model;

public enum BookingStatus {
    PENDING,
    BOOKED,
    CONFIRMED,
    CANCELLED,
    COMPLETED
}
