package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.*;
import com.example.multi_tanent.warehouse.service.*;
import com.stripe.exception.StripeException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:3000")
public class PaymentController {

    private final PaymentService paymentService;
    private final BookingService bookingService;
    private final InvoiceService invoiceService;
    private final EmailService emailService;
    private final CustomerService customerService;

    public PaymentController(PaymentService paymentService,
                             BookingService bookingService,
                             InvoiceService invoiceService,
                             EmailService emailService,
                             CustomerService customerService) {
        this.paymentService = paymentService;
        this.bookingService = bookingService;
        this.invoiceService = invoiceService;
        this.emailService = emailService;
        this.customerService = customerService;
    }

    @PostMapping("/create-session")
    public ResponseEntity<?> createSession(@RequestBody Map<String, Object> data) throws StripeException {
        System.out.println("🎯 [DEBUG] /create-session hit with: " + data);

        Long bookingId = Long.valueOf(data.get("bookingId").toString());
        Booking booking = bookingService.getBookingById(bookingId);

        double base = booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0;
        double extra = booking.getExtraAmount() != null ? booking.getExtraAmount() : 0.0;

        double totalToPay = 0.0;
        if (BookingStatus.CONFIRMED.equals(booking.getStatus()) && extra > 0) {
            totalToPay = extra; // already paid rent, now pay only extra
        } else {
            totalToPay = base + extra; // normal case
        }

        if (totalToPay <= 0) {
            throw new RuntimeException("Invalid payment amount");
        }

        System.out.println("💰 Total Payable for booking #" + bookingId + " = ₹" + totalToPay);
        data.put("amount", totalToPay * 100); // Stripe amount in paise
        data.put("currency", "INR");

        return ResponseEntity.ok(paymentService.createStripeSession(data));
    }

    @PostMapping("/confirm")
    public ResponseEntity<Payment> confirmPayment(@RequestBody Map<String, Object> data) {
        System.out.println("🎯 [DEBUG] /confirm hit with: " + data);

        Payment payment = paymentService.confirmStripePayment(data);
        if (payment == null) {
            return ResponseEntity.badRequest().build();
        }

        Booking booking = payment.getBooking();
        if (booking == null) {
            return ResponseEntity.badRequest().build();
        }

        double base = booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0;
        double extra = booking.getExtraAmount() != null ? booking.getExtraAmount() : 0.0;
        double totalPaid = base + extra;

        booking.setStatus(BookingStatus.CONFIRMED);
        bookingService.save(booking);

        payment.setAmount(totalPaid);
        payment.setStatus("PAID");
        paymentService.save(payment);

        invoiceService.createInvoiceForBooking(booking, payment);

        try {
            Customer customer = booking.getCustomer();
            if (customer != null) {
                String subject = "✅ Payment Confirmation - Car Rental Booking";
                String body = "Hello " + customer.getFullNameEnglish() + ",\n\n" +
                        "Your payment has been successfully received.\n\n" +
                        "Booking ID: " + booking.getId() + "\n" +
                        "Car Rent: ₹" + base + "\n" +
                        "Extra Charges: ₹" + extra + "\n" +
                        "Total Paid: ₹" + totalPaid + "\n\n" +
                        "Thank you for choosing our service!\n" +
                        "Car Rental Website Team";

                emailService.sendEmailNotification(customer.getEmail(), subject, body);
            }
        } catch (Exception e) {
            System.err.println("❌ Email send failed: " + e.getMessage());
        }

        return ResponseEntity.ok(payment);
    }

    @GetMapping
    public ResponseEntity<?> listPayments() {
        return ResponseEntity.ok(paymentService.findAll());
    }
}
