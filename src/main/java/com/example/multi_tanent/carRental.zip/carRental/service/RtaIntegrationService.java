package com.example.multi_tanent.warehouse.service;

import com.example.multi_tanent.warehouse.dto.FineDto;
import com.example.multi_tanent.warehouse.dto.VehicleDto;
import java.util.List;

public interface RtaIntegrationService {
    String getAccessToken();
    List<FineDto> getSalikFinesByVehicle(String plateNumber);
    VehicleDto getVehicleDetails(String plateNumber);
}
