//package com.example.multi_tanent.warehouse.controller;
//
//import com.example.multi_tanent.warehouse.model.*;
//import com.example.multi_tanent.warehouse.repository.UserRepository;
//import com.example.multi_tanent.warehouse.service.*;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.web.bind.annotation.*;
//
//import java.security.Principal;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//import java.time.temporal.ChronoUnit;
//import java.util.List;
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api/bookings")
//@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
//public class BookingController {
//
//    private final BookingService bookingService;
//    private final UserRepository userRepository;
//    private final CustomerService customerService;
//    private final EmailService emailService;
//    private final VehicleService vehicleService; // ✅ Added
//
//    public BookingController(BookingService bookingService,
//                             UserRepository userRepository,
//                             CustomerService customerService,
//                             EmailService emailService,
//                             VehicleService vehicleService) { // ✅ Added
//        this.bookingService = bookingService;
//        this.userRepository = userRepository;
//        this.customerService = customerService;
//        this.emailService = emailService;
//        this.vehicleService = vehicleService; // ✅ Added
//    }
//
//    private int calculateRentalDays(LocalDate pickupDate, LocalDate returnDate) {
//        long days = ChronoUnit.DAYS.between(pickupDate, returnDate);
//        return (days < 1) ? 1 : (int) days + 1;
//    }
//
//    @PreAuthorize("hasAnyRole('ADMIN','USER')")
//    @GetMapping("/my-bookings")
//    public ResponseEntity<List<Booking>> getMyBookings(Principal principal) {
//        User user = userRepository.findByUsername(principal.getName())
//                .orElseThrow(() -> new RuntimeException("User not found: " + principal.getName()));
//        List<Booking> bookings = bookingService.getBookingsByUser(user);
//        return ResponseEntity.ok(bookings);
//    }
//
//    @PostMapping("/save")
//    @PreAuthorize("hasAnyRole('ADMIN','USER')")
//    public ResponseEntity<?> create(@RequestBody Map<String, Object> payload, Principal principal) {
//        try {
//            User loggedInUser = userRepository.findByUsername(principal.getName())
//                    .orElseThrow(() -> new RuntimeException("User not found: " + principal.getName()));
//
//            Long vehicleId = Long.valueOf(payload.get("vehicleId").toString());
//            Long customerId = Long.valueOf(payload.get("customerId").toString());
//
//            String category = null;
//            if (payload.get("category") != null) {
//                category = payload.get("category").toString().trim();
//                if (category.isEmpty()) category = null;
//            }
//
//            Customer customer = customerService.getCustomerById(customerId);
//
//            Booking booking = new Booking();
//            booking.setUser(loggedInUser);
//            booking.setCustomer(customer);
//
//            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
//            booking.setPickupDate(LocalDate.parse(payload.get("pickupDate").toString(), formatter));
//            booking.setReturnDate(LocalDate.parse(payload.get("returnDate").toString(), formatter));
//
//            booking.setPickupLocation(payload.get("pickupLocation").toString());
//            booking.setDropLocation(payload.get("dropLocation").toString());
//
//            int rentalDays = calculateRentalDays(booking.getPickupDate(), booking.getReturnDate());
//            booking.setRentalDays(rentalDays);
//
//            Booking savedBooking = bookingService.createBooking(booking, vehicleId, customer, category);
//
//            String subject = "Booking Confirmation - " + savedBooking.getId();
//            String body = "Dear " + customer.getFullNameEnglish() + ",\n\n" +
//                    "Your booking has been confirmed.\n" +
//                    "Pickup Date: " + savedBooking.getPickupDate() + "\n" +
//                    "Return Date: " + savedBooking.getReturnDate() + "\n" +
//                    "Pickup Location: " + savedBooking.getPickupLocation() + "\n" +
//                    "Drop Location: " + savedBooking.getDropLocation() + "\n\n" +
//                    "Thank you for choosing our service!\n\n" +
//                    "Car Rental Website Team";
//
//            emailService.sendEmailNotification(customer.getEmail(), subject, body);
//            return ResponseEntity.ok(savedBooking);
//        } catch (Exception ex) {
//            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
//        }
//    }
//
//    @PreAuthorize("hasRole('ADMIN')")
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> delete(@PathVariable Long id) {
//        bookingService.deleteBooking(id);
//        return ResponseEntity.noContent().build();
//    }
//
//    @PreAuthorize("hasRole('ADMIN')")
//    @GetMapping
//    public ResponseEntity<List<Booking>> listAll() {
//        List<Booking> allBookings = bookingService.getAllBookings();
//        return ResponseEntity.ok(allBookings);
//    }
//
//    // ✅ FIXED SECTION — Update booking with extra charges when completed
//    @PutMapping("/{id}/complete")
//    @PreAuthorize("hasAnyRole('ADMIN','USER')")
//    public ResponseEntity<?> completeBooking(@PathVariable Long id) {
//        try {
//            Booking booking = bookingService.getBookingById(id);
//            Vehicle vehicle = vehicleService.findById(booking.getVehicle().getId());
//
//            // ✅ Pull latest extra values from Vehicle table
//            double extraKm = vehicle.getExtraKm() != null ? vehicle.getExtraKm() : 0.0;
//            double extraCharge = vehicle.getExtraCharge() != null ? vehicle.getExtraCharge() : 0.0;
//
//            booking.setExtraKmCharges(extraKm);
//            booking.setExtraAmount(extraCharge);
//
//            double total = (booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0) + extraCharge;
//            booking.setTotalPrice(total);
//
//            booking.setStatus(BookingStatus.COMPLETED);
//            Booking completedBooking = bookingService.save(booking);
//
//            return ResponseEntity.ok(completedBooking);
//        } catch (Exception ex) {
//            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
//        }
//    }
//}
package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.*;
import com.example.multi_tanent.warehouse.repository.UserRepository;
import com.example.multi_tanent.warehouse.service.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class BookingController {

    private final BookingService bookingService;
    private final UserRepository userRepository;
    private final CustomerService customerService;
    private final EmailService emailService;
    private final VehicleService vehicleService;

    public BookingController(BookingService bookingService,
                             UserRepository userRepository,
                             CustomerService customerService,
                             EmailService emailService,
                             VehicleService vehicleService) {
        this.bookingService = bookingService;
        this.userRepository = userRepository;
        this.customerService = customerService;
        this.emailService = emailService;
        this.vehicleService = vehicleService;
    }

    // Utility method for rental days
    private int calculateRentalDays(LocalDate pickupDate, LocalDate returnDate) {
        long days = ChronoUnit.DAYS.between(pickupDate, returnDate);
        return (days < 1) ? 1 : (int) days + 1;
    }

    // 🟢 Fetch bookings for logged-in user
    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    @GetMapping("/my-bookings")
    public ResponseEntity<List<Booking>> getMyBookings(Principal principal) {
        User user = userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found: " + principal.getName()));
        List<Booking> bookings = bookingService.getBookingsByUser(user);
        return ResponseEntity.ok(bookings);
    }

    // 🟢 Create new booking
    @PostMapping("/save")
    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<?> create(@RequestBody Map<String, Object> payload, Principal principal) {
        try {
            User loggedInUser = userRepository.findByUsername(principal.getName())
                    .orElseThrow(() -> new RuntimeException("User not found: " + principal.getName()));

            Long vehicleId = Long.valueOf(payload.get("vehicleId").toString());
            Long customerId = Long.valueOf(payload.get("customerId").toString());
            String category = (payload.get("category") != null) ? payload.get("category").toString().trim() : null;

            Customer customer = customerService.getCustomerById(customerId);
            Vehicle vehicle = vehicleService.findById(vehicleId);

            if (vehicle == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Vehicle not found"));
            }

            Booking booking = new Booking();
            booking.setUser(loggedInUser);
            booking.setCustomer(customer);
            booking.setVehicle(vehicle);

            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
            booking.setPickupDate(LocalDate.parse(payload.get("pickupDate").toString(), formatter));
            booking.setReturnDate(LocalDate.parse(payload.get("returnDate").toString(), formatter));
            booking.setPickupLocation(payload.get("pickupLocation").toString());
            booking.setDropLocation(payload.get("dropLocation").toString());

            int rentalDays = calculateRentalDays(booking.getPickupDate(), booking.getReturnDate());
            booking.setRentalDays(rentalDays);

            // Calculate total based on vehicle rate
            double baseRate = vehicle.getDailyRate() != null ? vehicle.getDailyRate() : 0.0;
            booking.setTotalPrice(baseRate * rentalDays);
            booking.setStatus(BookingStatus.CONFIRMED);
            booking.setExtraAmount(0.0);

            // Optionally capture start odometer at booking creation if vehicle currentOdometer exists
            if (vehicle.getCurrentOdometer() != null) {
                booking.setStartOdometer(vehicle.getCurrentOdometer());
            }

            Booking savedBooking = bookingService.createBooking(booking, vehicleId, customer, category);

            // Send confirmation email (best-effort)
            try {
                String subject = "Booking Confirmation - " + savedBooking.getId();
                String body = "Dear " + customer.getFullNameEnglish() + ",\n\n" +
                        "Your booking has been confirmed.\n" +
                        "Pickup Date: " + savedBooking.getPickupDate() + "\n" +
                        "Return Date: " + savedBooking.getReturnDate() + "\n" +
                        "Pickup Location: " + savedBooking.getPickupLocation() + "\n" +
                        "Drop Location: " + savedBooking.getDropLocation() + "\n\n" +
                        "Thank you for choosing our service!\n\n" +
                        "Car Rental Website Team";
                emailService.sendEmailNotification(customer.getEmail(), subject, body);
            } catch (Exception ignored) { }

            return ResponseEntity.ok(savedBooking);
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    // 🟢 Delete booking (Admin)
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        bookingService.deleteBooking(id);
        return ResponseEntity.noContent().build();
    }

    // 🟢 List all bookings (Admin)
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<Booking>> listAll() {
        List<Booking> allBookings = bookingService.getAllBookings();
        return ResponseEntity.ok(allBookings);
    }

    /**
     * Complete booking and apply extra charges.
     * Accepts optional JSON body with "startOdometer" and "endOdometer" (numbers).
     *
     * Priority for odometer values:
     * 1) Provided in request body
     * 2) Stored on booking.startOdometer / booking.endOdometer
     * 3) vehicle.currentOdometer (only for endOdometer fallback)
     *
     * If insufficient information to compute driven kms, the endpoint will still mark COMPLETE
     * but will NOT apply extra charges.
     */
    @PutMapping("/{id}/complete")
    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<?> completeBooking(@PathVariable Long id, @RequestBody(required = false) Map<String, Object> body) {
        try {
            Booking booking = bookingService.getBookingById(id);
            if (booking == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Booking not found"));
            }

            Vehicle vehicle = vehicleService.findById(booking.getVehicle().getId());
            if (vehicle == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Vehicle not found"));
            }

            // Read odometer values from request body if provided
            Double providedStart = null;
            Double providedEnd = null;
            if (body != null) {
                if (body.get("startOdometer") != null) {
                    try { providedStart = Double.valueOf(body.get("startOdometer").toString()); } catch (Exception ignored) {}
                }
                if (body.get("endOdometer") != null) {
                    try { providedEnd = Double.valueOf(body.get("endOdometer").toString()); } catch (Exception ignored) {}
                }
            }

            // Determine startOdometer: priority -> providedStart -> booking.startOdometer
            double startOdometer = providedStart != null ? providedStart :
                    (booking.getStartOdometer() != null ? booking.getStartOdometer() : Double.NaN);

            // Determine endOdometer: priority -> providedEnd -> booking.endOdometer -> vehicle.currentOdometer
            double endOdometer = providedEnd != null ? providedEnd :
                    (booking.getEndOdometer() != null ? booking.getEndOdometer() :
                            (vehicle.getCurrentOdometer() != null ? vehicle.getCurrentOdometer() : Double.NaN));

            boolean canComputeKm = !Double.isNaN(startOdometer) && !Double.isNaN(endOdometer);

            double kmsDriven = 0.0;
            double extraKms = 0.0;
            double totalExtraCharge = 0.0;

            if (canComputeKm) {
                // compute kms driven and ensure non-negative
                kmsDriven = Math.max(0.0, endOdometer - startOdometer);

                // determine allowed kms: if vehicle.kmsLimit is set -> use it; else fallback to rentalDays * dailyOdometerLimit if available
                double allowedKms = 0.0;
                if (vehicle.getKmsLimit() != null && vehicle.getKmsLimit() > 0) {
                    allowedKms = vehicle.getKmsLimit();
                } else if (vehicle.getDailyOdometerLimit() != null && vehicle.getDailyOdometerLimit() > 0) {
                    allowedKms = vehicle.getDailyOdometerLimit() * Math.max(1, booking.getRentalDays());
                }

                extraKms = Math.max(0.0, kmsDriven - allowedKms);

                double ratePerKm = vehicle.getExtraKmCharge() != null ? vehicle.getExtraKmCharge() : 0.0;
                totalExtraCharge = extraKms * ratePerKm;

                // Persist odometer values to booking (if provided)
                if (providedStart != null) booking.setStartOdometer(providedStart);
                if (providedEnd != null) booking.setEndOdometer(providedEnd);
                // If booking didn't have start but vehicle had current at booking creation, don't override unless provided.
            } else {
                // cannot compute kms — but allow completion with no extra charges
                // you might prefer to require odometer values in such case; currently we mark completed but extra = 0
            }

            // Update booking computed fields
            booking.setTotalKmsDriven(kmsDriven);
            booking.setExtraKmCharges(extraKms);
            booking.setExtraAmount(totalExtraCharge);

            // Update total price
            double prevTotal = booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0;
            booking.setTotalPrice(prevTotal + totalExtraCharge);

            booking.setStatus(BookingStatus.COMPLETED);

            // Update vehicle current odometer if we have an end reading
            if (!Double.isNaN(endOdometer)) {
                vehicle.setCurrentOdometer(endOdometer);
                // Save vehicle (if vehicleService.save exists)
                try { vehicleService.save(vehicle); } catch (Exception ignored) {}
            }

            Booking completedBooking = bookingService.save(booking);

            return ResponseEntity.ok(completedBooking);

        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    // 🟢 Manually update extra charges (Admin)
    @PutMapping("/{id}/extra")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> addExtraCharge(@PathVariable Long id, @RequestParam double extraAmount) {
        try {
            Booking booking = bookingService.getBookingById(id);
            if (booking == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Booking not found"));
            }

            double newTotal = (booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0) + extraAmount;
            booking.setExtraAmount(extraAmount);
            booking.setTotalPrice(newTotal);

            Booking updated = bookingService.save(booking);
            return ResponseEntity.ok(updated);
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }
}

