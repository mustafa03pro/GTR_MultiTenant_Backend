package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.Branch;
import com.example.multi_tanent.warehouse.service.BranchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/branches")
public class BranchController {
    private final BranchService service;
    public BranchController(BranchService service) { this.service = service; }


    @GetMapping
    public ResponseEntity<List<Branch>> list() {
        return ResponseEntity.ok(service.findAll());
    }


    @PostMapping
    public ResponseEntity<Branch> create(@RequestBody Branch branch) {
        return ResponseEntity.ok(service.save(branch));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Branch> get(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }
}
