package com.example.multi_tanent.carRental.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "pricing")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pricing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String category; // e.g., SUV, SEDAN
    private Double dailyRate;
    private Double weeklyRate;
    private Double monthlyRate;
    private Double excessMileagePerKm;
    private Double discountPercentage;
}
