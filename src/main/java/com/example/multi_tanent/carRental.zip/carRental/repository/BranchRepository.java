package com.example.multi_tanent.warehouse.repository;

import com.example.multi_tanent.warehouse.model.Branch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BranchRepository extends JpaRepository<Branch , Long> {

}
