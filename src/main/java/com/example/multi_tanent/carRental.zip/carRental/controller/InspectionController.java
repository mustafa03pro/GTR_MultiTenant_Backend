package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.Inspection;
import com.example.multi_tanent.warehouse.service.InspectionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/inspections")
public class InspectionController {

    private final InspectionService inspectionService;

    public InspectionController(InspectionService inspectionService) {
        this.inspectionService = inspectionService;
    }

    @PostMapping
    public ResponseEntity<Inspection> createInspection(@RequestPart("inspection") Inspection inspection,
                                                       @RequestPart(value = "images", required = false) List<MultipartFile> images) {
        Inspection created = inspectionService.createInspection(inspection, images);
        return ResponseEntity.ok(created);
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<Inspection> getByBooking(@PathVariable Long bookingId) {
        Inspection inspection = inspectionService.findByBookingId(bookingId);
        return ResponseEntity.ok(inspection);
    }

    @GetMapping
    public ResponseEntity<List<Inspection>> listAll() {
        List<Inspection> inspections = inspectionService.getAllInspections();
        return ResponseEntity.ok(inspections);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Inspection> updateInspection(@PathVariable Long id,
                                                       @RequestPart("inspection") Inspection inspection,
                                                       @RequestPart(value = "images", required = false) List<MultipartFile> images) {
        Inspection updated = inspectionService.updateInspection(id, inspection, images);
        return ResponseEntity.ok(updated);
    }
}
