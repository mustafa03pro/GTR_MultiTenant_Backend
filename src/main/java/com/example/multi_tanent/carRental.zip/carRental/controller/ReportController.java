package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.repository.BookingRepository;
import com.example.multi_tanent.warehouse.repository.VehicleRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final BookingRepository bookingRepo;
    private final VehicleRepository vehicleRepo;
    public ReportController(BookingRepository bookingRepo, VehicleRepository vehicleRepo) {
        this.bookingRepo = bookingRepo;
        this.vehicleRepo = vehicleRepo;
    }

    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> summary() {
        long totalBookings = bookingRepo.count();
        long totalVehicles = vehicleRepo.count();
        return ResponseEntity.ok(Map.of("totalBookings", totalBookings, "totalVehicles", totalVehicles));
    }
}
