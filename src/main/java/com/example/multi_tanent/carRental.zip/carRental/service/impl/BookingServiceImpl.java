package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.exception.ResourceNotFoundException;
import com.example.multi_tanent.warehouse.model.*;
import com.example.multi_tanent.warehouse.repository.BookingRepository;
import com.example.multi_tanent.warehouse.repository.VehicleRepository;
import com.example.multi_tanent.warehouse.service.BookingService;
import com.example.multi_tanent.warehouse.service.PricingService;
import com.example.multi_tanent.warehouse.service.VehicleService;
import org.springframework.stereotype.Service;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final VehicleRepository vehicleRepository;
    private final PricingService pricingService;
    private final VehicleService vehicleService;

    public BookingServiceImpl(
            BookingRepository bookingRepository,
            VehicleRepository vehicleRepository,
            PricingService pricingService,
            VehicleService vehicleService) {
        this.bookingRepository = bookingRepository;
        this.vehicleRepository = vehicleRepository;
        this.pricingService = pricingService;
        this.vehicleService = vehicleService;
    }

    @Override
    public Booking createBooking(Booking booking, Long vehicleId, Customer customer, String category) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with ID: " + vehicleId));

        if (!"AVAILABLE".equalsIgnoreCase(vehicle.getStatus())) {
            throw new IllegalStateException("Vehicle is not available for booking.");
        }

        booking.setCustomer(customer);
        booking.setVehicle(vehicle);

        if (booking.getPickupDate() != null && booking.getReturnDate() != null) {
            long days = ChronoUnit.DAYS.between(booking.getPickupDate(), booking.getReturnDate()) + 1;
            booking.setRentalDays((int) Math.max(days, 1));
        } else {
            booking.setRentalDays(Math.max(1, booking.getRentalDays()));
        }

        String finalCategory = determineFinalCategory(vehicle, category);

        double totalPrice = pricingService.calculateTotalPriceWithExtras(
                vehicleId,
                booking.getRentalDays(),
                0.0,
                finalCategory
        );

        booking.setTotalPrice(totalPrice);
        booking.setStartOdometer(vehicle.getCurrentOdometer() != null ? vehicle.getCurrentOdometer() : 0.0);
        booking.setTotalKmsDriven(0.0);
        booking.setExtraKmCharges(0.0);
        booking.setStatus(BookingStatus.BOOKED); // ✅ FIXED

        Booking savedBooking = bookingRepository.save(booking);

        vehicle.setStatus("BOOKED");
        vehicleRepository.save(vehicle);

        return savedBooking;
    }

    private String determineFinalCategory(Vehicle vehicle, String payloadCategory) {
        if (payloadCategory != null && !payloadCategory.trim().isEmpty()) {
            return payloadCategory.trim();
        }
        if (vehicle.getCategory() != null && !vehicle.getCategory().trim().isEmpty()) {
            return vehicle.getCategory().trim();
        }
        if (vehicle.getVehicleCategories() != null && !vehicle.getVehicleCategories().isEmpty()) {
            String first = vehicle.getVehicleCategories().get(0);
            if (first != null && !first.trim().isEmpty()) return first.trim();
        }
        return "DEFAULT";
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Booking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + id));
    }

    @Override
    public void deleteBooking(Long id) {
        if (!bookingRepository.existsById(id)) {
            throw new ResourceNotFoundException("Booking not found with ID: " + id);
        }
        bookingRepository.deleteById(id);
    }

    @Override
    public Booking updateBookingStatus(Long bookingId, BookingStatus status) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + bookingId));
        booking.setStatus(status);
        return bookingRepository.save(booking);
    }

    @Override
    public double calculateQuotation(Long vehicleId, java.time.LocalDate pickupDate, java.time.LocalDate returnDate) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with ID: " + vehicleId));

        int days = (int) ChronoUnit.DAYS.between(pickupDate, returnDate) + 1;
        if (days < 1) days = 1;

        String finalCategory = determineFinalCategory(vehicle, null);

        return pricingService.calculateTotalPriceWithExtras(vehicleId, days, 0.0, finalCategory);
    }

    @Override
    public Booking save(Booking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public List<Booking> getBookingsByUser(User user) {
        return bookingRepository.findByUser(user);
    }

    @Override
    public Booking completeBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new IllegalStateException("Booking already completed");
        }

        Vehicle vehicle = vehicleRepository.findById(booking.getVehicle().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found: " + booking.getVehicle().getId()));

        double endOdo = vehicle.getCurrentOdometer() != null ? vehicle.getCurrentOdometer() : 0.0;
        booking.setEndOdometer(endOdo);

        double startOdo = booking.getStartOdometer() != null ? booking.getStartOdometer() : 0.0;
        double driven = endOdo - startOdo;

        if (driven < 0) driven = 0;

        booking.setTotalKmsDriven(driven);

        double extraChargeAmount = 0.0;
        if (vehicle.getKmsLimit() != null && vehicle.getExtraKmCharge() != null) {
            double limit = vehicle.getKmsLimit();
            if (driven > limit) {
                double extraKm = driven - limit;
                extraChargeAmount = extraKm * vehicle.getExtraKmCharge();
            }
        }

        booking.setExtraKmCharges(extraChargeAmount);

        double oldPrice = booking.getTotalPrice() != null ? booking.getTotalPrice() : 0.0;
        booking.setTotalPrice(oldPrice + extraChargeAmount);

        booking.setStatus(BookingStatus.COMPLETED);

        vehicle.setStatus("AVAILABLE");
        vehicleRepository.save(vehicle);

        return bookingRepository.save(booking);
    }
}
