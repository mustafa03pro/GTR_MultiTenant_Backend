package com.example.multi_tanent.warehouse.service.impl;

import com.example.multi_tanent.warehouse.exception.ResourceNotFoundException;
import com.example.multi_tanent.warehouse.model.Company;
import com.example.multi_tanent.warehouse.repository.CompanyRepository;
import com.example.multi_tanent.warehouse.service.CompanyService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CompanyServiceImpl implements CompanyService {
    private final CompanyRepository companyRepository ;

    public CompanyServiceImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public Company createCompany(Company company) {
        return companyRepository.save(company);
    }

    @Override
    public Company updateCompany(Long id, Company company) {
        Company existing = companyRepository.findById(id).orElseThrow(()->
                new ResourceNotFoundException("Company not found with ID: " + id));
        existing.setName(company.getName());
        existing.setBranches(company.getBranches());
        existing.setTaxDetails(company.getTaxDetails());
        existing.setBankAccountInfo(company.getBankAccountInfo());
        return companyRepository.save(existing) ;
    }

    @Override
    public List<Company> getAllCompanies() {
        return companyRepository.findAll();
    }

    @Override
    public Company getCompanyById(Long id) {
        return companyRepository.findById(id).orElseThrow(()->new
                ResourceNotFoundException("Company not found with ID: " + id));
    }

    @Override
    public void deleteCompany(Long id) {
        if(!companyRepository.existsById(id)){
            throw new ResourceNotFoundException("Company not found with ID: " + id);
        }
    }
}
