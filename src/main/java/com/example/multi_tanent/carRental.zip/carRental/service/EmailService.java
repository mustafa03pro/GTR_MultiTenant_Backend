package com.example.multi_tanent.warehouse.service;

    public interface EmailService {
    void sendEmailNotification(String toEmail , String subject , String body) ;
}
