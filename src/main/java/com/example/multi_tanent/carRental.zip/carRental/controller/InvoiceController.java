package com.example.multi_tanent.warehouse.controller;

import com.example.multi_tanent.warehouse.model.Invoice;
import com.example.multi_tanent.warehouse.service.InvoiceService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;

    public InvoiceController(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    // ✅ Fetch all invoices
    @GetMapping
    public ResponseEntity<List<Invoice>> listAll() {
        return ResponseEntity.ok(invoiceService.findAll());
    }

    // ✅ Fetch invoice by ID
    @GetMapping("/{id}")
    public ResponseEntity<Invoice> getById(@PathVariable Long id) {
        return ResponseEntity.ok(invoiceService.findById(id));
    }

    // ✅ Fetch invoice by booking ID
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<?> getByBookingId(@PathVariable Long bookingId) {
        return invoiceService.findByBookingId(bookingId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ✅ Create manual invoice (optional)
    @PostMapping
    public ResponseEntity<?> create(@RequestBody Invoice invoice) {
        try {
            Invoice created = invoiceService.create(invoice);
            return ResponseEntity.ok(created);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/booking/{bookingId}/download")
    public ResponseEntity<byte[]> downloadInvoice(@PathVariable Long bookingId) {
        byte[] pdfBytes = invoiceService.generateInvoicePdf(bookingId);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=Invoice-" + bookingId + ".pdf")
                .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}
