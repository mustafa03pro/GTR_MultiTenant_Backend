package com.example.multi_tanent.warehouse.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "customers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Profile
    private String profileType;           // Individual, Company
    private String profileCategory;       // Regular, VIP
    private String preferredLanguage;
    @Column(name = "full_name_english")
    private String fullNameEnglish;
    private String gender;
    private String nationality;
    private LocalDate dateOfBirth;
    private String placeOfBirth;

    // Identity & Contact
    private String identityCardNo;
    private String phone;
    private String homeAddress;
    private String homePhone;
    private String workAddress;
    private String profession;
    @Column(name = "email_address", unique = true)
    private String email;

    // Driving License
    private String licenseNumber;
    private String drivingLicenseIssuedBy;
    private LocalDate drivingLicenseIssuedDate;
    private LocalDate drivingLicenseExpiryDate;

    // Passport
    private String passportNo;
    private LocalDate passportIssuedDate;
    private LocalDate passportExpiryDate;

    // Additional Info
    @Column(name = "mobile")
    private String mobile; // default prefix “00971”
    private String motherName;
}
